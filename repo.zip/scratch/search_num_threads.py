with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    content = f.read()

print("Is 'set_num_threads' in app.py?", 'set_num_threads' in content)
if 'set_num_threads' in content:
    for idx, line in enumerate(content.splitlines()):
        if 'set_num_threads' in line:
            print(f"Line {idx+1}: {line.strip()}")
