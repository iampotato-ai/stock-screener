import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

c.execute("SELECT COUNT(DISTINCT symbol) FROM daily_bars")
print("Distinct symbols in daily_bars:", c.fetchone()[0])

c.execute("SELECT DISTINCT symbol FROM daily_bars LIMIT 20")
print("Sample symbols:")
for row in c.fetchall():
    print(f"  {row[0]}")

conn.close()
