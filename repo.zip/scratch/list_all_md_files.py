import os
import sys
sys.stdout.reconfigure(encoding='utf-8')

workspace = r'c:\Users\91996\Documents\My Projects\stock-screener'
for root, dirs, files in os.walk(workspace):
    for f in files:
        if f.endswith('.md'):
            path = os.path.join(root, f)
            print(f"\n--- {path} ---")
            try:
                with open(path, 'r', encoding='utf-8') as file:
                    for _ in range(5):
                        line = file.readline()
                        if not line:
                            break
                        print(line.strip())
            except Exception as e:
                print("Error reading:", e)
print("\nSearch complete.")
