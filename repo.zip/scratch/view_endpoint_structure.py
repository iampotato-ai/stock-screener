import sys
sys.stdout.reconfigure(encoding='utf-8')

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'def api_ensemble_forecast' in line:
        print(f"Line {idx+1}: {line.strip()}")
        # print next 130 lines
        for j in range(idx, idx+130):
            if j < len(lines):
                print(f"{j+1}: {lines[j].rstrip()}")
        break
