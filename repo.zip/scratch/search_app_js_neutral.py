import sys
sys.stdout.reconfigure(encoding='utf-8')

path = r"c:\Users\91996\Documents\My Projects\stock-screener\static\js\app.js"
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

import re
matches = re.finditer(r'(unpredicted|neutral)', content, re.IGNORECASE)
count = 0
for m in matches:
    start = max(0, m.start() - 60)
    end = min(len(content), m.end() + 60)
    print(f"Match: {content[start:end].strip().replace('\n', ' ')}")
    count += 1
    if count >= 30:
        break
print("Done.")
