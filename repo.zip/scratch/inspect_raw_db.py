import re

def inspect():
    with open('scan_history.db', 'rb') as f:
        data = f.read()
        
    date_pattern = re.compile(rb'(\d{4}-\d{2}-\d{2})')
    matches = list(date_pattern.finditer(data))
    
    bands = [b'Bull Run', b'Bullish', b'Neutral', b'Bearish', b'Bear Market']
    
    count = 0
    for m in matches:
        date_pos = m.start()
        date_val = m.group(1).decode('ascii')
        
        window = data[date_pos:date_pos+150]
        
        # Check if any band is in window
        found_band = None
        for b in bands:
            if b in window:
                found_band = b
                break
                
        if found_band:
            count += 1
            print(f"Match {count}: Date: {date_val} at position {date_pos}")
            print(f"  Hex: {window.hex()}")
            print(f"  ASCII: {repr(window)}")
            if count >= 5:
                break

if __name__ == '__main__':
    inspect()
