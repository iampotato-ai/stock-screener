import os
import sys
sys.stdout.reconfigure(encoding='utf-8')

workspace = r'c:\Users\91996\Documents\My Projects\stock-screener'
for root, dirs, files in os.walk(workspace):
    for f in files:
        if f.endswith('.py'):
            path = os.path.join(root, f)
            try:
                with open(path, 'r', encoding='utf-8') as file:
                    content = file.read()
                if 'def kronos_predict' in content:
                    print(f"Found in {path}")
            except Exception as e:
                pass
print("Search complete.")
