import os
import sys
sys.stdout.reconfigure(encoding='utf-8')

workspace = r'c:\Users\91996\Documents\My Projects\stock-screener'
for root, dirs, files in os.walk(workspace):
    for f in files:
        if f.endswith('.py') or f.endswith('.js') or f.endswith('.html'):
            path = os.path.join(root, f)
            try:
                with open(path, 'r', encoding='utf-8') as file:
                    content = file.read()
                if 'Neutral / Unpredicted' in content or 'Neutral' in content:
                    # check exact string
                    if 'Neutral / Unpredicted' in content:
                        print(f"Found match in {path}")
            except Exception:
                pass
print("Search complete.")
