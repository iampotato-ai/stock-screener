import sqlite3

def main():
    conn = sqlite3.connect('scan_history.db')
    c = conn.cursor()
    c.execute("DELETE FROM kronos_forecasts WHERE model_type = 'ensemble'")
    conn.commit()
    print(f"Successfully deleted {c.rowcount} cached ensemble forecast rows.")
    conn.close()

if __name__ == '__main__':
    main()
