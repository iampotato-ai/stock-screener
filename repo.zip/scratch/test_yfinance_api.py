import urllib.request
import json
import sys

symbol = "CAPILLARY.NS"
url = f"https://query2.finance.yahoo.com/v7/finance/quote?symbols={symbol}"
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

try:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as response:
        data = json.loads(response.read().decode('utf-8'))
        
    result = data.get("quoteResponse", {}).get("result", [])
    if not result:
        print("ERROR: No result found in quote")
        sys.exit(1)
        
    print("Found keys:")
    for k, v in result[0].items():
        if "eps" in k.lower() or "profit" in k.lower() or "revenue" in k.lower() or "earnings" in k.lower():
            print(f"  {k}: {v}")
            
except Exception as e:
    print("Failed to fetch from Yahoo Finance quote:", e)
