import os
import sys
sys.stdout.reconfigure(encoding='utf-8')

brain_dir = r'C:\Users\91996\.gemini\antigravity\brain\edf246d5-649b-41e1-b712-ccc288cf2203'
for root, dirs, files in os.walk(brain_dir):
    for f in files:
        path = os.path.join(root, f)
        # print relative path
        rel = os.path.relpath(path, brain_dir)
        print(rel)
print("Done.")
