import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.stdout.reconfigure(encoding='utf-8')

from app import app, kronos_predict, prophet_predict, arima_predict
from concurrent.futures import ThreadPoolExecutor
import traceback

ticker = "RELIANCE.NS"
horizon = 10

with app.app_context():
    def run_kronos():
        try:
            return kronos_predict(ticker, horizon)
        except Exception as e:
            print("KRONOS EXCEPTION IN THREAD:")
            traceback.print_exc()
            raise e

    def run_prophet():
        try:
            return prophet_predict(ticker, horizon)
        except Exception as e:
            print("PROPHET EXCEPTION IN THREAD:")
            traceback.print_exc()
            raise e

    def run_arima():
        try:
            return arima_predict(ticker, horizon)
        except Exception as e:
            print("ARIMA EXCEPTION IN THREAD:")
            traceback.print_exc()
            raise e

    runners = {'kronos': run_kronos, 'prophet': run_prophet, 'arima': run_arima}

    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {name: executor.submit(fn) for name, fn in runners.items()}
        for name, future in futures.items():
            try:
                res = future.result(timeout=12)
                print(f"{name} returned: {res}")
            except Exception as e:
                print(f"future.result for {name} raised: {type(e)} - {e}")
