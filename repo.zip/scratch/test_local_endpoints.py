import urllib.request
import json

def check_scan_stats():
    url = "http://127.0.0.1:5000/api/scan?limit=500"
    print(f"Fetching: {url}")
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req) as response:
        html = response.read().decode('utf-8')
        result = json.loads(html)
        
        stocks = result.get('data', [])
        print(f"\nTotal scanned stocks: {len(stocks)}")
        
        historical_stocks = []
        for stock in stocks:
            first_seen = stock.get('first_seen', '')
            if first_seen and first_seen < '2026-06-18':
                historical_stocks.append(stock)
                
        print(f"Found {len(historical_stocks)} stocks with historical scan history (First Seen < 2026-06-18):")
        for idx, stock in enumerate(historical_stocks[:20]):
            ticker = stock.get('clean_ticker')
            first_seen = stock.get('first_seen')
            times_seen = stock.get('times_seen_20d')
            days_in_scan = stock.get('days_in_scan')
            print(f"[{idx+1}] Ticker: {ticker:12s} | First Seen: {first_seen:10s} | Seen (20d): {times_seen:2d} | Days in Scan: {days_in_scan}")

if __name__ == '__main__':
    try:
        check_scan_stats()
    except Exception as e:
        print(f"Error: {e}")
