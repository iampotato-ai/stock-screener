import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.stdout.reconfigure(encoding='utf-8')

from app import app, kronos_predict
import threading
import traceback

def run_test():
    with app.app_context():
        try:
            print("Thread started. Running kronos_predict...")
            res = kronos_predict("RELIANCE.NS", 10)
            print("Thread Success! Result:", res)
        except Exception as e:
            print("Thread Exception caught:", type(e), e)
            print("Thread Traceback:")
            traceback.print_exc()

t = threading.Thread(target=run_test)
t.start()
t.join()
