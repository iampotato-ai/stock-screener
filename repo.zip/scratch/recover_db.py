import struct
import re

def recover_data():
    with open('scan_history.db', 'rb') as f:
        data = f.read()

    bands = [b'Bull Run', b'Bullish', b'Neutral', b'Bearish', b'Bear Market']
    
    # Date pattern: YYYY-MM-DD
    date_pattern = re.compile(rb'(\d{4}-\d{2}-\d{2})')
    
    results = []
    seen = set()

    for match in date_pattern.finditer(data):
        date_pos = match.start()
        date_val = match.group(1).decode('ascii')
        
        # Look around date_pos for time and regime band
        # SQLite records store columns in order:
        # date (TEXT), time (TEXT), advances (INT), declines (INT), unchanged (INT), 
        # pct_sma21 (REAL), pct_sma50 (REAL), pct_52high (REAL), avg_recommend (REAL), 
        # regime_score (INT), regime_band (TEXT)
        
        # Typically the header is before the date string, and the date string is followed by time, etc.
        # Let's search a window of 150 bytes starting from date_pos
        window = data[date_pos:date_pos+150]
        
        # Find time HH:MM or HH:MM:SS
        time_match = re.search(rb'^.{10,20}?(\d{2}:\d{2}(?::\d{2})?)', window)
        if not time_match:
            continue
            
        time_val = time_match.group(1).decode('ascii')
        time_pos_in_window = time_match.start(1)
        
        # Find regime band in window
        found_band = None
        band_pos_in_window = -1
        for b in bands:
            b_match = re.search(re.escape(b), window)
            if b_match:
                found_band = b.decode('ascii')
                band_pos_in_window = b_match.start()
                break
                
        if not found_band:
            continue
            
        # We found date, time, and band!
        # Let's see if we can decode the columns in between!
        # Between time (ends at time_pos_in_window + len(time)) and band (starts at band_pos_in_window):
        # We have: advances (INT), declines (INT), unchanged (INT), 4 floats (each 8 bytes), regime_score (INT)
        # SQLite integers can be 1, 2, 3, 4, 6, 8 bytes or even 0/1 header-only.
        # Let's look for the 4 floats (each 8 bytes) which should be consecutive!
        # The floats are: pct_sma21, pct_sma50, pct_52high, avg_recommend
        
        # Let's extract the slice of bytes where the floats should reside
        float_bytes_start = time_pos_in_window + len(time_val)
        # Usually there are 3 integers (advances, declines, unchanged) between time and the floats.
        # Let's try different offsets for the start of the 4 floats
        for offset in range(3, 15):
            start_idx = float_bytes_start + offset
            if start_idx + 32 <= band_pos_in_window:
                float_part = window[start_idx:start_idx+32]
                try:
                    floats = struct.unpack('>dddd', float_part)
                    # Check if these look like valid percentages/ratings (usually 0.0 to 100.0)
                    if all(0.0 <= fl <= 100.0 or 0.0 <= fl <= 5.0 for fl in floats):
                        # We found the floats!
                        # Let's try to extract advances, declines, unchanged from the bytes before the floats
                        int_part = window[float_bytes_start:start_idx]
                        # Let's parse the integers using simple SQLite varint/integer parsing or heuristics
                        # Since they are small numbers, they are likely 1 or 2 bytes each
                        ints = []
                        idx = 0
                        while idx < len(int_part):
                            b = int_part[idx]
                            if b < 128:
                                ints.append(b)
                                idx += 1
                            else:
                                # 2-byte varint
                                if idx + 1 < len(int_part):
                                    val = ((b & 127) << 7) | int_part[idx+1]
                                    ints.append(val)
                                    idx += 2
                                else:
                                    break
                                    
                        # Let's verify we got at least 3 integers
                        if len(ints) >= 3:
                            adv, dec, unc = ints[0], ints[1], ints[2]
                            
                            # Let's get regime_score (integer before the band)
                            score_bytes = window[start_idx+32:band_pos_in_window]
                            score = 0
                            if score_bytes:
                                score = score_bytes[-1] # heuristic: last byte is the score
                                
                            key = (date_val, time_val)
                            if key not in seen:
                                seen.add(key)
                                results.append({
                                    'date': date_val,
                                    'time': time_val,
                                    'advances': adv,
                                    'declines': dec,
                                    'unchanged': unc,
                                    'pct_sma21': round(floats[0], 2),
                                    'pct_sma50': round(floats[1], 2),
                                    'pct_52high': round(floats[2], 2),
                                    'avg_recommend': round(floats[3], 2),
                                    'regime_score': score,
                                    'regime_band': found_band
                                })
                                break
                except struct.error:
                    continue

    print(f"Recovered {len(results)} rows:")
    for r in sorted(results, key=lambda x: (x['date'], x['time'])):
        print(f"  {r['date']} {r['time']} | {r['regime_band']} (Score: {r['regime_score']}) | Adv/Dec/Unc: {r['advances']}/{r['declines']}/{r['unchanged']} | SMA21/50/52W: {r['pct_sma21']}/{r['pct_sma50']}/{r['pct_52high']} | Rec: {r['avg_recommend']}")

    # Let's insert them back into breadth_history!
    if results:
        import sqlite3
        conn = sqlite3.connect('scan_history.db')
        c = conn.cursor()
        inserted = 0
        for r in results:
            try:
                c.execute("""
                    INSERT OR REPLACE INTO breadth_history (
                        date, time, advances, declines, unchanged, 
                        pct_sma21, pct_sma50, pct_52high, avg_recommend, 
                        regime_score, regime_band
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    r['date'], r['time'], r['advances'], r['declines'], r['unchanged'],
                    r['pct_sma21'], r['pct_sma50'], r['pct_52high'], r['avg_recommend'],
                    r['regime_score'], r['regime_band']
                ))
                inserted += 1
            except sqlite3.Error as e:
                print(f"Insert error for {r['date']}: {e}")
        conn.commit()
        conn.close()
        print(f"Successfully restored {inserted} rows to breadth_history table!")

if __name__ == '__main__':
    recover_data()
