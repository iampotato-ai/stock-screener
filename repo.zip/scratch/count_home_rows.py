import sqlite3

conn = sqlite3.connect('scratch/scan_history_home.db')
c = conn.cursor()
c.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = [t[0] for t in c.fetchall()]
print("Row counts in home folder database tables:")
for t in tables:
    c.execute(f"SELECT COUNT(*) FROM {t}")
    count = c.fetchone()[0]
    print(f"  {t}: {count}")

if 'breadth_history' in tables:
    c.execute("SELECT * FROM breadth_history ORDER BY date DESC LIMIT 20")
    rows = c.fetchall()
    print("\nLatest 20 rows in home folder database breadth_history:")
    for r in rows:
        print(f"  {r}")

conn.close()
