with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for j in range(1765, 1795):
    print(f"{j+1}: {lines[j].rstrip()}")
