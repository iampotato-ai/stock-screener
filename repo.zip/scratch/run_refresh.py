import sys
sys.path.append('.')
from app import refresh_ipo_metrics, sqlite3

print("Running refresh_ipo_metrics()...")
try:
    refresh_ipo_metrics()
    print("Done!")
    # Check cache count
    conn = sqlite3.connect('scan_history.db')
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM ipo_metrics_cache")
    print("New cache count:", c.fetchone()[0])
    conn.close()
except Exception as e:
    import traceback
    traceback.print_exc()
