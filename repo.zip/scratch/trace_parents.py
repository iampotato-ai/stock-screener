import re

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\templates\index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

stack = []
for i, line in enumerate(lines, 1):
    tokens = re.split(r'(<div|<\/div>)', line)
    for token in tokens:
        if token == '<div':
            stack.append((i, line.strip()[:60]))
        elif token == '</div>':
            if stack:
                stack.pop()
    
    if i == 1917:
        print("=== Parent stack at line 1917 ===")
        for idx, tag in stack:
            print(f"  Line {idx}: {tag}")
