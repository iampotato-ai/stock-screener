with open("static/js/app.js", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "btnIms.addEventListener" in line or "imsDropdown.classList.toggle" in line or "select-trigger" in line or "dropdown" in line:
        if any(w in line for w in ["addEventListener", "click", "toggle", "btn-", "btnIms", "btnSwing"]):
            print(f"{i+1}: {line.strip()}")
