import requests
import json
import sys

def run_tests():
    base_url = 'http://127.0.0.1:5000'
    ticker = 'TCS'
    horizon = 10
    
    print(f"=== Testing Ensemble Forecast for {ticker} ===")
    forecast_url = f"{base_url}/api/ensemble_forecast"
    payload = {
        'ticker': ticker,
        'horizon': horizon,
        'use_dynamic_weights': True
    }
    
    try:
        r = requests.post(forecast_url, json=payload)
        if r.status_code != 200:
            print(f"Failed forecast! Status: {r.status_code}")
            print(r.text)
            sys.exit(1)
            
        data = r.json()
        print(f"Status: SUCCESS")
        print(f"Weights Source: {data.get('weights_source')}")
        print(f"Weights: {data.get('weights')}")
        print(f"Consensus Conviction: {data.get('conviction')}")
        print(f"Divergence Score: {data.get('divergence_score')}")
        print(f"Latency: {data.get('latency_ms')} ms")
        print(f"Ensemble Path (first 3): {data.get('ensemble_path')[:3]}...")
        
        # Assertions
        assert data.get('weights_source') == 'dynamic', "Expected dynamic weight source"
        assert 'kronos' in data.get('weights'), "Expected kronos in weights"
        assert len(data.get('ensemble_path')) == horizon, f"Expected ensemble path length of {horizon}"
        print("Forecast Assertions: PASSED")
        
    except Exception as e:
        print(f"Error testing forecast: {e}")
        sys.exit(1)
        
    print(f"\n=== Testing Ensemble Backtest for {ticker} ===")
    backtest_url = f"{base_url}/api/ensemble-backtest?ticker={ticker}&horizon={horizon}"
    try:
        r = requests.get(backtest_url)
        if r.status_code != 200:
            print(f"Failed backtest! Status: {r.status_code}")
            print(r.text)
            sys.exit(1)
            
        data = r.json()
        print("Status: SUCCESS")
        print("Keys in response:", list(data.keys()))
        print("Per Model Metrics:")
        for m, m_data in data.get('per_model_metrics', {}).items():
            print(f"  {m}: MAE={m_data.get('mae')}, MAPE={m_data.get('mape')}%, DirAcc={m_data.get('direction_accuracy')}%")
            
        # Assertions
        assert 'per_model_metrics' in data, "Expected per_model_metrics in backtest response"
        assert 'ensemble' in data.get('per_model_metrics'), "Expected ensemble metrics"
        assert len(data.get('comparison_points')) > 0, "Expected comparison points"
        print("Backtest Assertions: PASSED")
        
    except Exception as e:
        print(f"Error testing backtest: {e}")
        sys.exit(1)
        
    print("\nALL DYNAMICS VERIFICATION TESTS COMPLETED SUCCESSFULLY!")

if __name__ == '__main__':
    run_tests()
