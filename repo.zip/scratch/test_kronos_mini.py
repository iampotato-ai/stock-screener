import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import torch
import sys
import os

# Add project root to python path so we can import model
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from model import Kronos, KronosTokenizer, KronosPredictor

def run_test():
    print("Loading Kronos-Tokenizer-2k...")
    tokenizer = KronosTokenizer.from_pretrained("NeoQuasar/Kronos-Tokenizer-2k")
    
    print("Loading Kronos-mini model...")
    model = Kronos.from_pretrained("NeoQuasar/Kronos-mini")
    
    print("Initializing KronosPredictor...")
    predictor = KronosPredictor(model, tokenizer, max_context=2048)
    
    print("Creating dummy price data...")
    # Generate 120 periods of dummy historical OHLCV data
    np.random.seed(42)
    base_price = 100.0
    prices = []
    current_time = datetime.now() - timedelta(days=120)
    timestamps = []
    
    for i in range(120):
        current_time += timedelta(days=1)
        timestamps.append(current_time)
        
        change = np.random.normal(0.0, 1.0)
        base_price += change
        open_p = base_price
        close_p = base_price + np.random.normal(0.0, 0.5)
        high_p = max(open_p, close_p) + np.random.uniform(0, 0.5)
        low_p = min(open_p, close_p) - np.random.uniform(0, 0.5)
        volume = float(np.random.randint(1000, 5000))
        amount = float(volume * (open_p + close_p) / 2.0)
        
        prices.append({
            "open": open_p,
            "high": high_p,
            "low": low_p,
            "close": close_p,
            "volume": volume,
            "amount": amount
        })
        
    df = pd.DataFrame(prices)
    x_timestamps = pd.Series(timestamps)
    
    # Define future timestamps (10 days ahead)
    future_timestamps = []
    for i in range(10):
        current_time += timedelta(days=1)
        future_timestamps.append(current_time)
    y_timestamps = pd.Series(future_timestamps)
    
    print("Running forecasting prediction for next 10 periods...")
    pred_df = predictor.predict(
        df=df,
        x_timestamp=x_timestamps,
        y_timestamp=y_timestamps,
        pred_len=10,
        T=1.0,
        top_p=0.9,
        sample_count=1,
        verbose=True
    )
    
    print("\nForecasted prices:")
    print(pred_df)
    print("\nSuccess! Kronos-mini prediction works correctly!")

if __name__ == "__main__":
    run_test()
