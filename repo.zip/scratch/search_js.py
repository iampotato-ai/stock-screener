with open("static/js/app.js", "r", encoding="utf-8") as f:
    lines = f.readlines()

found = False
for i, line in enumerate(lines):
    if "function filterAndRender" in line or "function applyFilters" in line or "applyFilters(" in line or "filterAndRender(" in line:
        # print the surrounding 10 lines
        print(f"--- Occurrence at line {i+1} ---")
        for k in range(max(0, i-5), min(len(lines), i+15)):
            print(f"{k+1}: {lines[k].strip()}")
