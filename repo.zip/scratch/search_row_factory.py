import sys
sys.stdout.reconfigure(encoding='utf-8')

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    content = f.read()

print("Is 'row_factory' in app.py?", 'row_factory' in content)
if 'row_factory' in content:
    for idx, line in enumerate(content.splitlines()):
        if 'row_factory' in line:
            print(f"Line {idx+1}: {line.strip()}")
