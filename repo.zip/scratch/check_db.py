import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

# Get distinct dates in ep_features
c.execute("SELECT DISTINCT feature_date FROM ep_features ORDER BY feature_date DESC")
dates = c.fetchall()
print("Dates in ep_features:", dates)

# Check count of rows in ep_features
c.execute("SELECT COUNT(*) FROM ep_features")
total_count = c.fetchone()[0]
print("Total rows in ep_features:", total_count)

# Get some sample rows from latest date
if dates:
    latest_date = dates[0][0]
    print(f"\nSample rows for latest date '{latest_date}':")
    c.execute("""
        SELECT symbol, exchange, ep_type, ep_score, confidence, market_cap_cr
        FROM ep_features
        WHERE feature_date = ?
        ORDER BY ep_score DESC
        LIMIT 10
    """, (latest_date,))
    rows = c.fetchall()
    for r in rows:
        print(f"  {r[0]} ({r[1]}): type={r[2]}, score={r[3]}, confidence={r[4]}, mkt_cap={r[5]} Cr")
else:
    print("No dates found in ep_features.")

# Check the count of active watchlist
c.execute("SELECT COUNT(*) FROM ep_watchlist WHERE status = 'ACTIVE'")
print("\nActive watchlist count:", c.fetchone()[0])

conn.close()
