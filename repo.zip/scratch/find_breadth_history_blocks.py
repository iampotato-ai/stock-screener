def find_breadth_blocks():
    with open('scan_history.db', 'rb') as f:
        data = f.read()

    bands = [b'Bull Run', b'Bullish', b'Neutral', b'Bearish', b'Bear Market']
    
    for b in bands:
        import re
        matches = list(re.finditer(re.escape(b), data))
        print(f"Found {len(matches)} matches for band {b.decode('ascii')}")
        for i, m in enumerate(matches[:5]):
            start = max(0, m.start() - 50)
            end = min(len(data), m.end() + 50)
            print(f"  Match {i+1} at {m.start()}:")
            print(f"    Hex: {data[start:end].hex()}")
            print(f"    ASCII: {repr(data[start:end])}")

if __name__ == '__main__':
    find_breadth_blocks()
