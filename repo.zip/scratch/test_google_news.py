import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET

def fetch_google_news(ticker):
    query = urllib.parse.quote(f"{ticker} NSE India OR {ticker} stock")
    url = f"https://news.google.com/rss/search?q={query}&hl=en-IN&gl=IN&ceid=IN:en"
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            xml_data = response.read()
        
        root = ET.fromstring(xml_data)
        channel = root.find('channel')
        
        items = channel.findall('item')
        news_list = []
        for item in items[:5]:  # Get top 5
            title = item.find('title').text if item.find('title') is not None else ''
            link = item.find('link').text if item.find('link') is not None else ''
            pub_date = item.find('pubDate').text if item.find('pubDate') is not None else ''
            source = item.find('source').text if item.find('source') is not None else ''
            
            news_list.append({
                'title': title,
                'link': link,
                'pub_date': pub_date,
                'source': source
            })
            
        for n in news_list:
            print(f"- {n['title']} ({n['source']}) | {n['pub_date']}")
            
    except Exception as e:
        print(f"Error: {e}")

fetch_google_news("TCS")
fetch_google_news("RELIANCE")
