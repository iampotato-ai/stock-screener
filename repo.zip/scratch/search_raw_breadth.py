import re

def search_raw():
    with open('scan_history.db', 'rb') as f:
        data = f.read()

    bands = [b'Bull Run', b'Bullish', b'Neutral', b'Bearish', b'Bear Market']
    
    # We look for date patterns (YYYY-MM-DD)
    date_pattern = re.compile(rb'(\d{4}-\d{2}-\d{2})')
    
    results = []
    seen = set()
    
    for match in date_pattern.finditer(data):
        pos = match.start()
        date_str = match.group(1).decode('ascii')
        
        # Let's inspect a window of 200 bytes around the date
        window = data[max(0, pos - 50):min(len(data), pos + 150)]
        
        # Check if any band is present in the window
        found_band = None
        for b in bands:
            if b in window:
                found_band = b.decode('ascii')
                break
                
        if found_band:
            # Let's extract any time string HH:MM:SS or HH:MM in the window
            time_match = re.search(rb'(\d{2}:\d{2}:\d{2}|\d{2}:\d{2})', window)
            time_str = time_match.group(1).decode('ascii') if time_match else "None"
            
            key = (date_str, time_str, found_band)
            if key not in seen:
                seen.add(key)
                results.append((pos, date_str, time_str, found_band, window))
                
    print(f"Found {len(results)} potential raw records:")
    for pos, date_str, time_str, band, win in sorted(results, key=lambda x: (x[1], x[2])):
        # Print date, time, band and some surrounding context
        print(f"Pos: {pos} | Date: {date_str} | Time: {time_str} | Band: {band}")
        # Try to print ASCII representation of window
        printable = "".join(chr(b) if 32 <= b < 127 else "." for b in win)
        print(f"  Context: {printable[:150]}")

if __name__ == '__main__':
    search_raw()
