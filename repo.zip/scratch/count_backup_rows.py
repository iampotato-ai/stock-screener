import sqlite3

conn = sqlite3.connect('scratch/scan_history_backup.db')
c = conn.cursor()
c.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = [t[0] for t in c.fetchall()]
print("Row counts in backup tables:")
for t in tables:
    c.execute(f"SELECT COUNT(*) FROM {t}")
    count = c.fetchone()[0]
    print(f"  {t}: {count}")

# Let's inspect breadth_history if it exists
if 'breadth_history' in tables:
    c.execute("SELECT * FROM breadth_history ORDER BY date DESC LIMIT 10")
    rows = c.fetchall()
    print("\nLatest 10 rows in backup breadth_history:")
    for r in rows:
        print(f"  {r}")

conn.close()
