def main():
    filepath = 'static/js/app.js'
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    target = '            }\n        }\n    });\n\n// Function to show/hide fundamental'
    replacement = '            }\n        }\n    });\n}\n\n// Function to show/hide fundamental'
    
    # Check for both LF and CRLF
    if target in content:
        content = content.replace(target, replacement)
        print("Found and replaced with LF line endings.")
    elif target.replace('\n', '\r\n') in content:
        content = content.replace(target.replace('\n', '\r\n'), replacement.replace('\n', '\r\n'))
        print("Found and replaced with CRLF line endings.")
    else:
        print("Target string not found in app.js.")
        # Let's inspect the surrounding text to see if there's any mismatch
        idx = content.find('// Function to show/hide fundamental')
        if idx != -1:
            print("Context before target:")
            print(repr(content[idx-100:idx]))
        else:
            print("Could not even find the comments.")
            
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

if __name__ == '__main__':
    main()
