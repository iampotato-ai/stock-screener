import os
import subprocess
import sys
sys.stdout.reconfigure(encoding='utf-8')

git_paths = [
    r"C:\Program Files\Git\bin\git.exe",
    r"C:\Program Files\Git\cmd\git.exe",
    r"C:\Users\91996\AppData\Local\Programs\Git\cmd\git.exe",
]

git_exe = None
for path in git_paths:
    if os.path.exists(path):
        git_exe = path
        break

if not git_exe:
    # search path
    try:
        res = subprocess.run(["where", "git"], capture_output=True, text=True)
        if res.returncode == 0:
            git_exe = res.stdout.strip().split('\n')[0]
    except Exception:
        pass

if git_exe:
    print(f"Found git at: {git_exe}")
    # run git log -n 5
    try:
        res = subprocess.run([git_exe, "log", "-n", "10", "--oneline"], capture_output=True, text=True, cwd=r"c:\Users\91996\Documents\My Projects\stock-screener")
        print("Git log:")
        print(res.stdout)
        
        # run git branch -a
        res_branch = subprocess.run([git_exe, "branch", "-a"], capture_output=True, text=True, cwd=r"c:\Users\91996\Documents\My Projects\stock-screener")
        print("Git branches:")
        print(res_branch.stdout)
    except Exception as e:
        print("Error running git:", e)
else:
    print("git.exe not found.")
