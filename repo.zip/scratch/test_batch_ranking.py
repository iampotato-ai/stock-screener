import urllib.request
import json
import time

def test_batch_ranking():
    url = "http://127.0.0.1:5000/api/watchlist/kronos-ranking?pred_len=5"
    print(f"Testing endpoint: {url}")
    
    start_time = time.time()
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=30) as response:
            duration = time.time() - start_time
            print(f"Request completed in {duration:.2f} seconds.")
            
            data = json.loads(response.read().decode('utf-8'))
            
            # Print high-level keys
            print("\nHigh-level response keys:")
            print(f"  generated_at: {data.get('generated_at')}")
            print(f"  pred_len: {data.get('pred_len')}")
            print(f"  partial: {data.get('partial')}")
            print(f"  missing_count: {data.get('missing_count')}")
            print(f"  sections count: {len(data.get('sections', []))}")
            
            for section in data.get('sections', []):
                print(f"\nSection: {section.get('name')} (ID: {section.get('id')}) | Partial: {section.get('partial')} | Missing: {section.get('missing_count')}")
                rankings = section.get('rankings', [])
                print(f"  Rankings count: {len(rankings)}")
                
                # Check sorting and keys
                prev_score = float('inf')
                sorted_correctly = True
                
                BIAS_WEIGHTS = {
                    'Strong Breakout': 100,
                    'Bullish Continuation': 75,
                    'Sideways Consolidation': 50,
                    'Bearish Pressure': 25,
                    'Strong Downtrend': 0
                }
                
                for r in rankings[:10]: # Print top 10
                    ticker = r.get('ticker')
                    rank = r.get('rank')
                    ret = r.get('predicted_return_pct')
                    bias = r.get('ai_forecast_bias')
                    conf = r.get('ai_confidence_score')
                    cache_hit = r.get('cache_hit')
                    
                    if bias is not None:
                        bias_w = BIAS_WEIGHTS.get(bias, 50)
                        comp_score = (conf * 0.6) + (bias_w * 0.4)
                    else:
                        comp_score = -9999
                    
                    print(f"    Rank {rank}: {ticker} | Return: {ret}% | Bias: {bias} | Conf: {conf}% | Comp Score: {comp_score:.2f} | Cached: {cache_hit}")
                    
                    if comp_score > prev_score:
                        sorted_correctly = False
                    prev_score = comp_score
                        
                print(f"  Sorted correctly: {sorted_correctly}")
                
    except Exception as e:
        print(f"Error testing batch ranking endpoint: {e}")

if __name__ == "__main__":
    test_batch_ranking()
