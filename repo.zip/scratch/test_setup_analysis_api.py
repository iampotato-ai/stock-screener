import requests
import json

def test_api():
    url = "http://127.0.0.1:5000/api/setup-analysis?ticker=RELIANCE"
    print(f"Querying setup analysis endpoint for RELIANCE: {url}...")
    try:
        r = requests.get(url, timeout=30)
        print("Status code:", r.status_code)
        if r.status_code == 200:
            data = r.json()
            print("Keys in response:", list(data.keys()))
            print("AI Forecast Bias:", data.get("ai_forecast_bias"))
            print("AI Confidence Score:", data.get("ai_confidence_score"))
            
            forecast = data.get("forecast_data", [])
            print("Forecast length:", len(forecast))
            if forecast:
                print("First forecasted candle:", json.dumps(forecast[0], indent=2))
                print("Last forecasted candle:", json.dumps(forecast[-1], indent=2))
            else:
                print("Warning: forecast_data is empty!")
        else:
            print("Error response text:", r.text)
    except Exception as e:
        print("Error connecting to API:", e)

if __name__ == "__main__":
    test_api()
