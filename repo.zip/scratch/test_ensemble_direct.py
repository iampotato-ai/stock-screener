import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.stdout.reconfigure(encoding='utf-8')

from app import app, kronos_predict, prophet_predict, arima_predict, ensemble_blend
import time
from concurrent.futures import ThreadPoolExecutor

ticker = "RELIANCE.NS"
horizon = 10

with app.app_context():
    results = {'kronos': None, 'prophet': None, 'arima': None}
    errors  = {'kronos': None, 'prophet': None, 'arima': None}

    def run_kronos():
        return kronos_predict(ticker, horizon)

    def run_prophet():
        return prophet_predict(ticker, horizon)

    def run_arima():
        return arima_predict(ticker, horizon)

    runners = {'kronos': run_kronos, 'prophet': run_prophet, 'arima': run_arima}

    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {name: executor.submit(fn) for name, fn in runners.items()}
        for name, future in futures.items():
            try:
                results[name] = future.result(timeout=30)
            except Exception as e:
                errors[name] = str(e)
                print(f"FAILED: {name} error: {e}")

    print("\nResults:")
    for k, v in results.items():
        print(f"  {k}: {v}")
    print("\nErrors:")
    for k, v in errors.items():
        print(f"  {k}: {v}")
