import sys
import re

# Set console encoding to UTF-8
sys.stdout.reconfigure(encoding='utf-8')

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    content = f.read()

print("Is 'kronos_predict' in app.py?", 'kronos_predict' in content)
if 'kronos_predict' in content:
    matches = re.finditer(r'kronos_predict', content)
    for m in matches:
        start = max(0, m.start() - 100)
        end = min(len(content), m.end() + 100)
        # clean up characters that might fail to print if any
        context_str = content[start:end].replace('\n', ' ')
        print(f"Context: {context_str}")
