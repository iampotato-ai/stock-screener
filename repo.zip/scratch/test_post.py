import requests
import json

url_snap = "http://127.0.0.1:5000/api/breadth-snapshot"
payload = {
    "advances": 100,
    "declines": 50,
    "unchanged": 10,
    "pctAboveSMA21": 65,
    "pctAboveSMA50": 60,
    "pctNear52High": 22,
    "avgRecommend": 75,
    "regimeScore": 80,
    "regimeBand": "Bull Run"
}

r1 = requests.post(url_snap, json=payload)
print("POST Response:", r1.status_code, r1.json())

url_hist = "http://127.0.0.1:5000/api/breadth-history"
r2 = requests.get(url_hist)
print("GET Response:", r2.status_code)
print(json.dumps(r2.json(), indent=2))
