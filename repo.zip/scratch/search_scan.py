import sys
sys.stdout.reconfigure(encoding='utf-8')

with open("app.py", "r", encoding="utf-8") as f:
    for idx, line in enumerate(f, 1):
        if "def run_scan" in line or "def scan" in line or "def fetch_all" in line or "/api/scan" in line:
            print(f"Line {idx}: {line.strip()}")
        elif "populate_screener_intelligence" in line:
            print(f"Line {idx}: {line.strip()}")
