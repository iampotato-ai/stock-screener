import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

# Get 20 sample symbols in daily_bars
c.execute("SELECT DISTINCT symbol FROM daily_bars LIMIT 20")
print("Sample symbols in daily_bars:")
print(c.fetchall())

conn.close()
