import sys
sys.stdout.reconfigure(encoding='utf-8')

with open("app.py", "r", encoding="utf-8") as f:
    for idx, line in enumerate(f, 1):
        if "def fetch_historical_prices" in line:
            print(f"Line {idx}: {line.strip()}")
        elif "def classify_technical_pattern" in line:
            print(f"Line {idx}: {line.strip()}")
