import subprocess
import os

def main():
    # Fetch original app.py from parent of commit 2dc53dc
    print("Fetching monolithic app.py from git history...")
    content = subprocess.check_output(['git', 'show', '2dc53dc~1:app.py']).decode('utf-8')
    
    # Let's write a python script to process and extract the legacy routes
    lines = content.splitlines()
    output_lines = []
    
    # We will add imports and setup at the top
    output_lines.append('"""')
    output_lines.append('Legacy compatibility routes and utility functions.')
    output_lines.append('"""')
    output_lines.append('from flask import request, jsonify, current_app, render_template')
    output_lines.append('from . import api_bp')
    output_lines.append('import os')
    output_lines.append('import sqlite3')
    output_lines.append('import time')
    output_lines.append('from datetime import datetime, date, timedelta')
    output_lines.append('import json')
    output_lines.append('import re')
    output_lines.append('import urllib.request')
    output_lines.append('from concurrent.futures import ThreadPoolExecutor')
    output_lines.append('import requests')
    output_lines.append('import numpy as np')
    output_lines.append('import pandas as pd')
    output_lines.append('import warnings')
    output_lines.append('import logging')
    output_lines.append('import threading')
    
    # We will import the new models, database connections or extensions if needed
    output_lines.append('from app.extensions import db')
    output_lines.append('from config import config')
    output_lines.append('from app.database import init_db_standalone')
    
    # Skip the original imports and app definition from the old app.py
    # We'll skip everything until the first global variable or function definition.
    # The first function in old app.py was around line 1290 (or we can just skip lines starting with import or app = Flask)
    skip_prefixes = (
        'import ', 'from ', 'app = Flask', 'db = SQLAlchemy', 'scheduler =', 
        'class ', 'CORS(app)', 'app.config', 'ma = ', 'init_extensions',
        'warnings.filterwarnings', 'logging.getLogger', 'warnings.simplefilter',
        'CORS(', 'warnings.warn'
    )
    
    # Let's also identify which routes we want to skip because they are already implemented in the new blueprints:
    # 1. Watchlist routes: get_watchlist, create_watchlist_section, rename_watchlist_section, delete_watchlist_section, add_watchlist_item, delete_watchlist_item, reorder_watchlist_sections, reorder_watchlist_items, migrate_local_data, get_watchlist_kronos_ranking
    # 2. Journal routes: get_journal, create_journal_entry, update_journal_entry, delete_journal_entry
    # 3. Breadth routes: save_breadth_snapshot, get_breadth_history
    # 4. IPO routes: get_ipo_listings, get_ipo_detail, api_refresh_ipo, debug_nse_ipo
    # 5. News: fetch_google_news / news endpoint (but wait, news endpoint in new blueprint is `/news`, so we can skip get_news)
    # 6. EP watchlist POST/remove/trigger: add_to_ep_watchlist, remove_from_ep_watchlist, trigger_ep_watchlist (implemented in ep_watchlist.py)
    
    skip_routes = {
        'get_watchlist', 'create_watchlist_section', 'rename_watchlist_section', 'delete_watchlist_section',
        'add_watchlist_item', 'delete_watchlist_item', 'reorder_watchlist_sections', 'reorder_watchlist_items',
        'migrate_local_data', 'get_watchlist_kronos_ranking',
        'get_journal', 'create_journal_entry', 'update_journal_entry', 'delete_journal_entry',
        'save_breadth_snapshot', 'get_breadth_history',
        'get_ipo_listings', 'get_ipo_detail', 'api_refresh_ipo', 'debug_nse_ipo',
        'add_to_ep_watchlist', 'remove_from_ep_watchlist', 'trigger_ep_watchlist',
        'index'  # index is served directly in app/__init__.py
    }
    
    in_skipped_function = False
    
    # Keep track of functions we process
    i = 0
    while i < len(lines):
        line = lines[i]
        
        # Skip top-level imports and app setup
        if i < 120:
            stripped = line.strip()
            if any(stripped.startswith(p) for p in skip_prefixes) or not stripped:
                i += 1
                continue
        
        # Detect route decorators and rewrite to api_bp
        if line.strip().startswith('@app.route'):
            # Check if this route is for one of our skipped functions
            # Lookahead to see the function definition
            j = i + 1
            is_skipped = False
            while j < len(lines):
                next_line = lines[j].strip()
                if next_line.startswith('def '):
                    func_name = next_line.split('(')[0].replace('def ', '').strip()
                    if func_name in skip_routes:
                        is_skipped = True
                    break
                elif next_line.startswith('@'):
                    j += 1
                else:
                    break
            
            if is_skipped:
                # Skip the decorator and the function
                i = j
                in_skipped_function = True
                i += 1
                continue
            else:
                # Rewrite @app.route to @api_bp.route and strip /api prefix
                line = line.replace('@app.route', '@api_bp.route')
                line = line.replace("'/api/", "'/")
                line = line.replace('"/api/', '"/')
        elif line.strip().startswith('@app.after_request'):
            line = line.replace('@app.after_request', '@api_bp.after_request')
        
        if in_skipped_function:
            # Skip until we hit a line that starts at column 0 and is not whitespace or comment
            if line.strip() and not line.startswith(' ') and not line.startswith('\t') and not line.startswith('@'):
                in_skipped_function = False
            else:
                i += 1
                continue
                
        # Also skip any block at the end (like app.run, etc.)
        if 'if __name__ == "__main__":' in line or 'if __name__ == \'__main__\':' in line:
            break
            
        output_lines.append(line)
        i += 1
        
    # Write to app/api/v1/legacy_routes.py
    os.makedirs('app/api/v1', exist_ok=True)
    with open('app/api/v1/legacy_routes.py', 'w', encoding='utf-8') as f:
        f.write('\n'.join(output_lines))
        
    print("Successfully built app/api/v1/legacy_routes.py!")

if __name__ == '__main__':
    main()
