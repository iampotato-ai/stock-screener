import sqlite3

def clean_ticker(ticker):
    if not ticker:
        return ""
    ticker = str(ticker).upper().strip()
    # Strip prefixes
    if ticker.startswith("NSE:"):
        ticker = ticker[4:]
    if ticker.startswith("BSE:"):
        ticker = ticker[4:]
    if ticker.startswith("BO:"):
        ticker = ticker[3:]
    # Strip suffixes
    if ticker.endswith(".NS"):
        ticker = ticker[:-3]
    if ticker.endswith(".BO"):
        ticker = ticker[:-3]
    return ticker

def backfill():
    conn = sqlite3.connect('scan_history.db')
    c = conn.cursor()
    
    print("Clearing scan_history first...")
    c.execute("DELETE FROM scan_history")
    
    # 1. Backfill from ep_features
    c.execute("SELECT DISTINCT feature_date, symbol FROM ep_features")
    ep_rows = c.fetchall()
    inserted_ep = 0
    for date, sym in ep_rows:
        if date and sym:
            clean = clean_ticker(sym)
            try:
                c.execute("INSERT OR IGNORE INTO scan_history (date, ticker) VALUES (?, ?)", (str(date), clean))
                inserted_ep += 1
            except sqlite3.Error as e:
                pass
    print(f"Inserted {inserted_ep} rows from ep_features.")

    # 2. Backfill from pattern_signals
    c.execute("SELECT DISTINCT bar_date, ticker FROM pattern_signals")
    ps_rows = c.fetchall()
    inserted_ps = 0
    for date, sym in ps_rows:
        if date and sym:
            clean = clean_ticker(sym)
            try:
                c.execute("INSERT OR IGNORE INTO scan_history (date, ticker) VALUES (?, ?)", (str(date), clean))
                inserted_ps += 1
            except sqlite3.Error as e:
                pass
    print(f"Inserted {inserted_ps} rows from pattern_signals.")

    # 3. Backfill from daily_bars
    c.execute("SELECT DISTINCT trade_date, symbol FROM daily_bars")
    db_rows = c.fetchall()
    inserted_db = 0
    for date, sym in db_rows:
        if date and sym:
            clean = clean_ticker(sym)
            try:
                c.execute("INSERT OR IGNORE INTO scan_history (date, ticker) VALUES (?, ?)", (str(date), clean))
                inserted_db += 1
            except sqlite3.Error as e:
                pass
    print(f"Inserted {inserted_db} rows from daily_bars.")

    # 4. Insert the current active scan runs data for 2026-06-18 and 2026-06-19 from scan_price_log
    # to preserve actual scans run since migration yesterday/today
    c.execute("SELECT DISTINCT date, ticker FROM scan_price_log")
    spl_rows = c.fetchall()
    inserted_spl = 0
    for date, sym in spl_rows:
        if date and sym:
            clean = clean_ticker(sym)
            try:
                c.execute("INSERT OR IGNORE INTO scan_history (date, ticker) VALUES (?, ?)", (str(date), clean))
                inserted_spl += 1
            except sqlite3.Error as e:
                pass
    print(f"Inserted {inserted_spl} rows from scan_price_log.")

    conn.commit()
    print("Post-backfill count of scan_history:", conn.execute("SELECT COUNT(*) FROM scan_history").fetchone()[0])
    
    # Check sample outputs
    c.execute("SELECT ticker, COUNT(*) as cnt, MIN(date) as first_seen FROM scan_history GROUP BY ticker ORDER BY cnt DESC LIMIT 15")
    print("\nTop 15 tickers and their backfilled metrics:")
    for row in c.fetchall():
        print(f"  Ticker: {row[0]:15s} | Appearances: {row[1]:4d} | First Seen: {row[2]}")
        
    conn.close()

if __name__ == '__main__':
    backfill()
