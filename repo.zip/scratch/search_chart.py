import sys
sys.stdout.reconfigure(encoding='utf-8')

with open("static/js/app.js", "r", encoding="utf-8") as f:
    for idx, line in enumerate(f, 1):
        if "createTradeDrawerChart" in line:
            print(f"Line {idx}: {line.strip()}")
        elif "activeDrawerChart" in line:
            print(f"Line {idx}: {line.strip()}")
