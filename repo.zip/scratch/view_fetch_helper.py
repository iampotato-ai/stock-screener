import sys
sys.stdout.reconfigure(encoding='utf-8')

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'def _fetch_price_history' in line:
        print(f"Line {idx+1}: {line.strip()}")
        for j in range(idx, idx+20):
            print(f"{j+1}: {lines[j].rstrip()}")
        break
