with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'def get_kronos_forecast' in line:
        print(f"Line {idx+1}: {line.strip()}")
        # scan forward for fetch_historical_prices
        for j in range(idx, idx+50):
            if 'fetch_historical_prices' in lines[j]:
                print(f"Line {j+1}: {lines[j].strip()}")
                break
        break
