import re

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

keywords = ['kronos_forecasts', 'kronos_predict', 'init_db', 'import ', '@app.route', '/api/kronos_forecast']
for i, line in enumerate(lines):
    for kw in keywords:
        if kw in line:
            print(f"Line {i+1}: {line.strip()}")
