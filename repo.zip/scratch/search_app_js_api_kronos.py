with open(r'c:\Users\91996\Documents\My Projects\stock-screener\static\js\app.js', 'r', encoding='utf-8') as f:
    content = f.read()

import re
matches = re.finditer(r'/api/kronos-forecast', content)
for m in matches:
    start = max(0, m.start() - 100)
    end = min(len(content), m.end() + 200)
    print(f"Match:\n{content[start:end].strip()}")
