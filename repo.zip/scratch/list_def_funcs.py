import re
import sys
sys.stdout.reconfigure(encoding='utf-8')

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    content = f.read()

# find all def lines
for line in content.splitlines():
    if line.strip().startswith('def ') and ('predict' in line or 'forecast' in line):
        print(line)
