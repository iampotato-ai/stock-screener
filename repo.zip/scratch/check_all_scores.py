import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

c.execute("SELECT DISTINCT feature_date FROM ep_features ORDER BY feature_date DESC LIMIT 1")
latest_date = c.fetchone()[0]

print(f"Latest Date: {latest_date}")
print("Score distributions:")
for threshold in [0.55, 0.50, 0.45, 0.40, 0.35, 0.30]:
    c.execute("SELECT COUNT(*) FROM ep_features WHERE feature_date = ? AND ep_score >= ?", (latest_date, threshold))
    cnt = c.fetchone()[0]
    print(f"  EP Score >= {threshold}: {cnt} candidates")

conn.close()
