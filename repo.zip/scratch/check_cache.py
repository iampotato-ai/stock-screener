import sqlite3, json

conn = sqlite3.connect('scan_history.db')
conn.row_factory = sqlite3.Row
rows = conn.execute(
    "SELECT ticker, model_type, generated_at, forecast_json FROM kronos_forecasts WHERE model_type='ensemble' ORDER BY generated_at DESC LIMIT 10"
).fetchall()
for r in rows:
    data = json.loads(r['forecast_json'])
    print(f"ticker={r['ticker']} at={r['generated_at']}")
    print(f"  keys: {list(data.keys())}")
    print(f"  active_models: {data.get('model_paths', {}).keys()}")
    print(f"  ensemble_path len: {len(data.get('ensemble_path', []))}")
    print(f"  errors: {data.get('model_errors', {})}")
    print()
conn.close()
