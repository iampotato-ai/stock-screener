import sqlite3
from app.api.v1.legacy_routes import fetch_screener_fundamentals, compute_yoy_metrics

def refresh_fundamentals_for_symbol(symbol):
    print(f"Fetching fundamentals for {symbol}...")
    quarters_data = fetch_screener_fundamentals(symbol)
    if not quarters_data:
        print(f"No quarters data returned for {symbol}")
        return
        
    quarters_data = compute_yoy_metrics(quarters_data)
    
    conn = sqlite3.connect('scan_history.db')
    c = conn.cursor()
    
    # We first delete existing records for the symbol to keep it clean,
    # or let INSERT OR REPLACE handle it. Let's delete existing first to avoid duplicate mismatches.
    c.execute("DELETE FROM fundamentals WHERE symbol = ?", (symbol.upper(),))
    
    inserted = 0
    for q in quarters_data:
        c.execute('''
            INSERT OR REPLACE INTO fundamentals (
                symbol, exchange, result_date, quarter, revenue, revenue_yoy_pct,
                net_profit, net_profit_yoy_pct, eps, eps_yoy_pct, surprise_type,
                consecutive_quarters_growth, source
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            symbol.upper(), 'NSE', q.get('result_date') or q['date_key'], q['quarter'], q['revenue'], q['revenue_yoy_pct'],
            q['net_profit'], q['net_profit_yoy_pct'], q['eps'], q.get('eps_yoy_pct'), q.get('surprise_type', 'UNKNOWN'),
            q.get('consecutive_quarters_growth', 0), q.get('source', 'unknown')
        ))
        inserted += 1
        
    conn.commit()
    conn.close()
    print(f"Successfully inserted {inserted} quarters of fundamentals for {symbol}.")

if __name__ == '__main__':
    refresh_fundamentals_for_symbol('ALLCARGO')
