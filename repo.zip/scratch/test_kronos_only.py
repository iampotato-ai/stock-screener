import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.stdout.reconfigure(encoding='utf-8')

from app import app, kronos_predict
import traceback

with app.app_context():
    try:
        print("Running kronos_predict...")
        res = kronos_predict("RELIANCE.NS", 10)
        print("Success! Result:", res)
    except Exception as e:
        print("Exception caught:", e)
        print("Traceback:")
        traceback.print_exc()
