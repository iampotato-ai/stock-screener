import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

# Run the update query to populate null price_change_pct in ep_features from daily_bars
c.execute("""
    UPDATE ep_features
    SET price_change_pct = (
        SELECT db.price_change_pct
        FROM daily_bars db
        WHERE db.symbol = ep_features.symbol
          AND db.trade_date = ep_features.feature_date
    )
    WHERE price_change_pct IS NULL
""")
print("Rows updated:", c.rowcount)
conn.commit()

# Verify the result
c.execute("SELECT feature_date, COUNT(*), COUNT(price_change_pct) FROM ep_features GROUP BY feature_date")
print("\nCounts per date after update:")
for r in c.fetchall():
    print(f"  Date: {r[0]}, Total: {r[1]}, Non-null Price Change: {r[2]}")

c.execute("""
    SELECT ep.symbol, ep.feature_date, ep.gap_pct, ep.price_change_pct, db.price_change_pct 
    FROM ep_features ep
    LEFT JOIN daily_bars db ON ep.symbol = db.symbol AND ep.feature_date = db.trade_date
    LIMIT 10
""")
print("\nSample records after update:")
for r in c.fetchall():
    print(f"Symbol: {r[0]}, Date: {r[1]}, EP Gap: {r[2]}%, EP Chg: {r[3]}, DB Chg: {r[4]}")

conn.close()
