import urllib.request
import json
import statistics
import math
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor

SECTOR_INDEX_MAP = {
    "Health Technology": "NIFTY_HLTHCARE.NS",
    "Health Services": "NIFTY_HLTHCARE.NS",
    "Finance": "NIFTY_FIN_SERVICE.NS",
    "Technology Services": "^CNXIT",
    "Electronic Technology": "^CNXIT",
    "Communications": "^CNXIT",
    "Retail Trade": "^CNXCONSUM",
    "Consumer Services": "^CNXCONSUM",
    "Consumer Durables": "^CNXCONSUM",
    "Consumer Non-Durables": "^CNXFMCG",
    "Process Industries": "^CNXMETAL",
    "Producer Manufacturing": "^CNXMETAL",
    "Non-Energy Minerals": "^CNXMETAL",
    "Utilities": "^CNXENERGY",
    "Energy Minerals": "^CNXENERGY",
    "Transportation": "^CNXINFRA",
    "Commercial Services": "^CNXINFRA",
    "Industrial Services": "^CNXINFRA"
}

def fetch_historical_prices(ticker, range_str="6mo"):
    symbol = ticker
    if not symbol.endswith(".NS") and not symbol.endswith(".BO") and not symbol.startswith("^"):
        symbol = f"{symbol}.NS"
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval=1d&range={range_str}"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        if not data.get('chart') or not data['chart'].get('result') or not data['chart']['result']:
            return []
        result = data['chart']['result'][0]
        timestamps = result.get('timestamp')
        if not timestamps:
            return []
        indicators = result.get('indicators', {})
        quote = indicators.get('quote', [{}])[0]
        adjclose = indicators.get('adjclose', [{}])[0].get('adjclose', quote.get('close', []))
        
        hist = []
        for i in range(len(timestamps)):
            close_val = adjclose[i] if i < len(adjclose) else None
            if close_val is None:
                continue
            date_str = datetime.utcfromtimestamp(timestamps[i]).strftime('%Y-%m-%d')
            hist.append({"date": date_str, "close": close_val})
        return hist
    except Exception as e:
        print(f"Error fetching {ticker}: {e}")
        return []

def test():
    print("Fetching benchmark ^NSEI...")
    bench_history = fetch_historical_prices("^NSEI", "6mo")
    if not bench_history:
        print("Failed to fetch benchmark.")
        return
    bench_dates = [d["date"] for d in bench_history]
    bench_closes = [d["close"] for d in bench_history]
    print(f"Fetched {len(bench_dates)} days of benchmark history.")
    
    # Get last trading day of each ISO week
    weeks_dates = {}
    for idx, entry in enumerate(bench_history):
        dt = datetime.strptime(entry["date"], "%Y-%m-%d")
        week_str = dt.strftime("%Y-W%W")
        # Keep the index as well so we can lookup 20 days ago
        weeks_dates[week_str] = (entry["date"], idx)
        
    sorted_weeks = sorted(weeks_dates.keys())
    target_weeks = sorted_weeks[-14:]
    print("Target weeks:", target_weeks)
    
    # Fetch sectors in parallel
    unique_tickers = list(set(SECTOR_INDEX_MAP.values()))
    sector_histories = {}
    print(f"Fetching {len(unique_tickers)} unique sector tickers...")
    with ThreadPoolExecutor(max_workers=8) as executor:
        futures = {executor.submit(fetch_historical_prices, ticker): ticker for ticker in unique_tickers}
        for fut in futures:
            ticker = futures[fut]
            sector_histories[ticker] = fut.result()
            
    print("Calculation check:")
    for sector, ticker in SECTOR_INDEX_MAP.items():
        history = sector_histories.get(ticker, [])
        if not history:
            continue
        history_map = {d["date"]: d["close"] for d in history}
        
        jdk_rs_list = []
        for w_str in target_weeks:
            date, idx = weeks_dates[w_str]
            if idx < 20:
                continue
            
            # Current prices
            close_now = history_map.get(date)
            bench_now = bench_closes[idx]
            
            # 20 days prior
            prior_date = bench_dates[idx - 20]
            close_prior = history_map.get(prior_date)
            bench_prior = bench_closes[idx - 20]
            
            if close_now is not None and close_prior is not None:
                sector_R = (close_now - close_prior) / close_prior * 100.0
                bench_R = (bench_now - bench_prior) / bench_prior * 100.0
                jdk_rs = (100.0 + sector_R) / (100.0 + bench_R) * 100.0
                jdk_rs_list.append((w_str, jdk_rs, date))
                
        # Calculate weekly momentum
        print(f"\nSector: {sector} ({ticker})")
        for i in range(1, len(jdk_rs_list)):
            w_str, val, date = jdk_rs_list[i]
            prev_w_str, prev_val, prev_date = jdk_rs_list[i - 1]
            rs_momentum = val - prev_val
            print(f"  {w_str} | Date: {date} | jdk_rs: {val:.3f} | momentum: {rs_momentum:.3f}")

if __name__ == "__main__":
    test()
