import requests
import json

BASE_URL = "http://127.0.0.1:5000"

def test_api():
    print("Starting Watchlist and Trade Journal API tests...")
    
    # 1. Bulk Migration Test
    migration_payload = {
        "watchlist_sections": [
            {
                "id": "sec-test-migrated",
                "name": "Migrated Watchlist",
                "stocks": ["RELIANCE", "TCS"]
            }
        ],
        "journal": [
            {
                "id": "trade-migrated-1",
                "ticker": "INFY",
                "name": "Infosys",
                "date": "2026-05-29",
                "setupLabel": "Breakout",
                "swingband": "strong",
                "entry": 1450.5,
                "stop": 1400.0,
                "target1": 1525.0,
                "target2": 1550.0,
                "target3": 1600.0,
                "riskAmount": 5000.0,
                "qty": 100,
                "status": "open",
                "notes": "Migrated trade log entry."
            }
        ]
    }
    
    print("\n--- Testing Migration Endpoint ---")
    r = requests.post(f"{BASE_URL}/api/migrate-local-data", json=migration_payload)
    print("Migration status code:", r.status_code)
    print("Migration response:", r.json())
    assert r.status_code == 200
    assert r.json().get("success") is True
    
    # 2. Get Watchlist Test
    print("\n--- Testing Get Watchlist ---")
    r = requests.get(f"{BASE_URL}/api/watchlist")
    print("Get Watchlist status code:", r.status_code)
    watchlist = r.json()
    print("Get Watchlist response (truncated):", str(watchlist)[:200])
    assert r.status_code == 200
    
    # Verify migrated section is present
    migrated_sec = next((s for s in watchlist if s["id"] == "sec-test-migrated"), None)
    assert migrated_sec is not None
    assert "RELIANCE" in migrated_sec["stocks"]
    assert "TCS" in migrated_sec["stocks"]
    
    # 3. Watchlist Section Operations
    print("\n--- Testing Section Creation ---")
    sec_id = "sec-temp-test"
    sec_name = "Temp Test Section"
    r = requests.post(f"{BASE_URL}/api/watchlist/sections", json={"id": sec_id, "name": sec_name})
    print("Create Section response:", r.json())
    assert r.status_code == 200
    
    print("\n--- Testing Section Renaming ---")
    new_name = "Renamed Temp Section"
    r = requests.put(f"{BASE_URL}/api/watchlist/sections/{sec_id}", json={"name": new_name})
    print("Rename Section response:", r.json())
    assert r.status_code == 200
    
    # Verify name updated
    r = requests.get(f"{BASE_URL}/api/watchlist")
    watchlist = r.json()
    temp_sec = next((s for s in watchlist if s["id"] == sec_id), None)
    assert temp_sec is not None
    assert temp_sec["name"] == new_name
    
    # 4. Item Operations
    print("\n--- Testing Adding Item ---")
    r = requests.post(f"{BASE_URL}/api/watchlist/items", json={"section_id": sec_id, "ticker": "WIPRO"})
    print("Add Item response:", r.json())
    assert r.status_code == 200
    
    # Verify added
    r = requests.get(f"{BASE_URL}/api/watchlist")
    temp_sec = next((s for s in r.json() if s["id"] == sec_id), None)
    assert "WIPRO" in temp_sec["stocks"]
    
    print("\n--- Testing Deleting Item ---")
    r = requests.delete(f"{BASE_URL}/api/watchlist/items", json={"section_id": sec_id, "ticker": "WIPRO"})
    print("Delete Item response:", r.json())
    assert r.status_code == 200
    
    # Verify deleted
    r = requests.get(f"{BASE_URL}/api/watchlist")
    temp_sec = next((s for s in r.json() if s["id"] == sec_id), None)
    assert "WIPRO" not in temp_sec["stocks"]
    
    print("\n--- Testing Section Deletion ---")
    r = requests.delete(f"{BASE_URL}/api/watchlist/sections/{sec_id}")
    print("Delete Section response:", r.json())
    assert r.status_code == 200
    
    # Verify section is deleted
    r = requests.get(f"{BASE_URL}/api/watchlist")
    temp_sec = next((s for s in r.json() if s["id"] == sec_id), None)
    assert temp_sec is None
    
    # 5. Journal Operations
    print("\n--- Testing Get Journal ---")
    r = requests.get(f"{BASE_URL}/api/journal")
    print("Get Journal status code:", r.status_code)
    journal = r.json()
    print("Get Journal response (truncated):", str(journal)[:200])
    assert r.status_code == 200
    
    # Verify migrated trade is present
    migrated_trade = next((t for t in journal if t["id"] == "trade-migrated-1"), None)
    assert migrated_trade is not None
    assert migrated_trade["ticker"] == "INFY"
    
    print("\n--- Testing Save Trade to Journal ---")
    trade_id = "trade-temp-test"
    new_trade = {
        "id": trade_id,
        "ticker": "SBI",
        "name": "State Bank of India",
        "date": "2026-05-30",
        "setupLabel": "Inside Bar",
        "swingband": "mixed",
        "entry": 800.0,
        "stop": 780.0,
        "qty": 250,
        "riskAmount": 5000.0,
        "status": "open",
        "notes": "Testing trade creation"
    }
    r = requests.post(f"{BASE_URL}/api/journal", json=new_trade)
    print("Save Trade response:", r.json())
    assert r.status_code == 200
    
    print("\n--- Testing Update Trade ---")
    update_data = {
        "status": "stopped",
        "exitPrice": 780.0,
        "exitDate": "2026-05-30",
        "pnl": -5000.0,
        "rAchieved": -1.0,
        "notes": "Hit stop loss manually."
    }
    r = requests.put(f"{BASE_URL}/api/journal/{trade_id}", json=update_data)
    print("Update Trade response:", r.json())
    assert r.status_code == 200
    
    # Verify updated
    r = requests.get(f"{BASE_URL}/api/journal")
    temp_trade = next((t for t in r.json() if t["id"] == trade_id), None)
    assert temp_trade is not None
    assert temp_trade["status"] == "stopped"
    assert temp_trade["pnl"] == -5000.0
    
    print("\n--- Testing Remove Trade ---")
    r = requests.delete(f"{BASE_URL}/api/journal/{trade_id}")
    print("Delete Trade response:", r.json())
    assert r.status_code == 200
    
    # Verify deleted
    r = requests.get(f"{BASE_URL}/api/journal")
    temp_trade = next((t for t in r.json() if t["id"] == trade_id), None)
    assert temp_trade is None
    
    print("\nAll API tests completed successfully!")

if __name__ == "__main__":
    test_api()
