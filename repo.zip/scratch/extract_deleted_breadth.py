import re

def extract_breadth():
    with open('scan_history.db', 'rb') as f:
        data = f.read()

    # Find date patterns like YYYY-MM-DD
    # and scan for nearby text like time (HH:MM) and regime band
    pattern = rb'(\d{4}-\d{2}-\d{2})'
    
    bands = [b'Bull Run', b'Bullish', b'Neutral', b'Bearish', b'Bear Market']
    
    # We will search the database file block by block or scan matches
    matches = list(re.finditer(pattern, data))
    print(f"Found {len(matches)} date matches in binary.")
    
    results = []
    seen = set()
    
    for m in matches:
        start = max(0, m.start() - 50)
        end = min(len(data), m.end() + 100)
        chunk = data[start:end]
        
        # Check if any band is in this chunk
        found_band = None
        for b in bands:
            if b in chunk:
                found_band = b.decode('ascii')
                break
                
        if found_band:
            # Let's extract date
            date_str = m.group(0).decode('ascii')
            
            # Let's find time of pattern HH:MM in chunk
            time_match = re.search(rb'\b(\d{2}:\d{2}(?::\d{2})?)\b', chunk)
            time_str = time_match.group(0).decode('ascii') if time_match else "00:00"
            
            key = (date_str, time_str)
            if key not in seen:
                seen.add(key)
                results.append((date_str, time_str, found_band, chunk))
                
    print(f"Extracted {len(results)} potential records:")
    for r in sorted(results, key=lambda x: (x[0], x[1])):
        print(f"  Date: {r[0]} | Time: {r[1]} | Band: {r[2]}")

if __name__ == '__main__':
    extract_breadth()
