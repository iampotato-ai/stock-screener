import os
import sys
sys.stdout.reconfigure(encoding='utf-8')

workspace = r'c:\Users\91996\Documents\My Projects\stock-screener'
for root, dirs, files in os.walk(workspace):
    for f in files:
        path = os.path.join(root, f)
        # ignore git and pycache
        if '.git' in path or '__pycache__' in path or 'scratch' in path:
            continue
        # check filename
        f_lower = f.lower()
        if 'review' in f_lower or 'pr' in f_lower or 'finding' in f_lower or 'ensemble' in f_lower:
            print(f"Found file by name: {path}")
        # check contents for ensemble review
        if f.endswith('.md') or f.endswith('.txt'):
            try:
                with open(path, 'r', encoding='utf-8') as file:
                    content = file.read()
                if 'ensemble' in content.lower() and ('review' in content.lower() or 'finding' in content.lower() or 'pr' in content.lower()):
                    print(f"Found keyword in contents of: {path}")
            except Exception as e:
                pass
print("Search complete.")
