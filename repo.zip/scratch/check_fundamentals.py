import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

for symbol in ['FOSECOIND', 'CAPILLARY']:
    c.execute("""
        SELECT symbol, quarter, result_date, revenue, revenue_yoy_pct, net_profit, net_profit_yoy_pct, eps, source
        FROM fundamentals
        WHERE symbol = ?
        ORDER BY result_date DESC
    """, (symbol,))
    rows = c.fetchall()
    print(f"\nFundamentals for {symbol}: (Count={len(rows)})")
    for r in rows:
        print(f"  {r[1]} ({r[2]}) - source={r[8]}: revenue={r[3]} Cr (YoY={r[4]}%), net_profit={r[5]} Cr (YoY={r[6]}%), eps={r[7]}")
        
conn.close()
