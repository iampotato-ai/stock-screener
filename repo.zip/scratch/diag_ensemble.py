"""
Inline diagnostic: test prophet_predict and arima_predict directly
without needing a running server.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

print("=== Importing app module (this loads all globals) ===")
import app
print("Import OK")

TICKER = "CGPOWER"

print(f"\n=== Step 1: fetch_historical_prices({TICKER}, 1y) ===")
try:
    hist = app.fetch_historical_prices(TICKER, range_str="1y")
    print(f"  Got {len(hist)} bars, last date: {hist[-1]['date'] if hist else 'N/A'}")
except Exception as e:
    print(f"  FAILED: {e}")

print(f"\n=== Step 2: fetch_historical_prices({TICKER}, 2y) ===")
try:
    hist2y = app.fetch_historical_prices(TICKER, range_str="2y")
    print(f"  Got {len(hist2y)} bars")
except Exception as e:
    print(f"  FAILED: {e}")

print(f"\n=== Step 3: prophet_predict({TICKER}, 5) ===")
try:
    result = app.prophet_predict(TICKER, horizon=5)
    print(f"  SUCCESS: {result}")
except Exception as e:
    import traceback
    print(f"  FAILED: {e}")
    traceback.print_exc()

print(f"\n=== Step 4: arima_predict({TICKER}, 5) ===")
try:
    result = app.arima_predict(TICKER, horizon=5)
    print(f"  SUCCESS: {result}")
except Exception as e:
    import traceback
    print(f"  FAILED: {e}")
    traceback.print_exc()

print(f"\n=== Step 5: kronos_predict({TICKER}, 5) ===")
try:
    result = app.kronos_predict(TICKER, horizon=5)
    print(f"  SUCCESS: {result}")
except Exception as e:
    import traceback
    print(f"  FAILED: {e}")
    traceback.print_exc()

print("\n=== Done ===")
