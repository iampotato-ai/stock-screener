import re

def find_all():
    with open('scan_history.db', 'rb') as f:
        data = f.read()

    bands = [b'Bull Run', b'Bullish', b'Neutral', b'Bearish', b'Bear Market']
    
    # We search for date pattern: YYYY-MM-DD
    # We want to scan a window of 100 bytes around any date pattern
    date_pattern = re.compile(rb'(\d{4}-\d{2}-\d{2})')
    
    results = []
    seen = set()
    
    for match in date_pattern.finditer(data):
        date_pos = match.start()
        date_val = match.group(1).decode('ascii')
        
        # Check a window of 120 bytes starting at date_pos
        window = data[date_pos:date_pos+120]
        
        # Check if any band is in this window
        found_band = None
        for b in bands:
            if b in window:
                found_band = b.decode('ascii')
                break
                
        if found_band:
            # Let's extract any readable text/time in window
            time_match = re.search(rb'(\d{2}:\d{2}(?::\d{2})?(\.\d+)?)', window)
            time_val = time_match.group(1).decode('ascii') if time_match else "Unknown"
            
            key = (date_val, time_val, found_band)
            if key not in seen:
                seen.add(key)
                results.append((date_val, time_val, found_band, window))
                
    print(f"Total potential breadth rows found: {len(results)}")
    for r in sorted(results, key=lambda x: (x[0], x[1])):
        print(f"Date: {r[0]} | Time: {r[1]} | Band: {r[2]}")
        print(f"  Hex: {r[3].hex()[:100]}")
        print(f"  ASCII: {repr(r[3][:100])}")

if __name__ == '__main__':
    find_all()
