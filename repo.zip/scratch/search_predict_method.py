import sys
sys.stdout.reconfigure(encoding='utf-8')

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    content = f.read()

# search for .predict(
import re
matches = re.finditer(r'\bpredict\(', content)
for m in matches:
    start = max(0, m.start() - 100)
    end = min(len(content), m.end() + 100)
    context_str = content[start:end].replace('\n', ' ')
    print(f"Match: {context_str}")
