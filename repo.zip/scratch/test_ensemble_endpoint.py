import requests
import json

def main():
    url = "http://127.0.0.1:5000/api/ensemble_forecast"
    payload = {
        "ticker": "RELIANCE",
        "horizon": 10,
        "use_dynamic_weights": False
    }
    
    # We first start the app in a background process if not running, 
    # but since the user has the app running, let's check if we can query it.
    try:
        response = requests.post(url, json=payload, timeout=20)
        print(f"Status Code: {response.status_code}")
        data = response.json()
        print(json.dumps(data, indent=2))
    except Exception as e:
        print(f"Error querying endpoint: {e}")

if __name__ == '__main__':
    main()
