import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

c.execute("""
    SELECT symbol, neglect_score, catalyst_score, repricing_score, ep_score,
           market_cap_cr, avg_turnover_cr, event_type, revenue_growth, profit_growth
    FROM ep_features
    WHERE symbol IN ('FOSECOIND', 'CAPILLARY')
    ORDER BY feature_date DESC
""")
rows = c.fetchall()
for r in rows:
    print(f"Symbol: {r[0]}")
    print(f"  Neglect Score: {r[1]}")
    print(f"  Catalyst Score: {r[2]}")
    print(f"  Repricing Score: {r[3]}")
    print(f"  EP Score: {r[4]}")
    print(f"  Mkt Cap: {r[5]} Cr, Turnover: {r[6]} Cr")
    print(f"  Event Type: {r[7]}, Rev Growth: {r[8]}%, Prof Growth: {r[9]}%")

conn.close()
