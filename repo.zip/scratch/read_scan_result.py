with open('scan_result.txt', 'r', encoding='utf-16') as f:
    content = f.read(5000)

print("First 5000 characters of scan_result.txt:")
print(content.encode('ascii', errors='replace').decode('ascii'))
