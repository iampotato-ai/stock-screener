with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'get_setup_analysis' in line:
        # scan forward for return jsonify(
        for j in range(idx, idx+150):
            if 'chart_data=' in lines[j]:
                print(f"Line {j+1}: {lines[j].strip()}")
                for k in range(j, j+15):
                    print(f"{k+1}: {lines[k].rstrip()}")
                break
        break
