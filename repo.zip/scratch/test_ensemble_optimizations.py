import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.stdout.reconfigure(encoding='utf-8')

from app import app, kronos_predict, prophet_predict, arima_predict, _fetch_price_history
import traceback

print("--- 1. Testing Stderr Log Suppression ---")
print("We will run prophet_predict. There should be NO 'cmdstanpy - INFO - Chain' printouts.")
with app.app_context():
    try:
        p = prophet_predict("RELIANCE.NS", 10)
        print("Success! Prophet predictions:", [round(x, 1) for x in p])
    except Exception as e:
        print("Prophet failed:", e)

print("\n--- 2. Testing Date Alignment ---")
with app.app_context():
    try:
        df_hist = _fetch_price_history("RELIANCE.NS")
        last_date = df_hist['ds'].iloc[-1]
        print("Last historical date:", last_date.strftime("%Y-%m-%d"))
        
        from app import generate_next_trading_days
        expected_dates = generate_next_trading_days(last_date.strftime("%Y-%m-%d"), 10)
        print("Expected future trading days:")
        for d in expected_dates:
            print(f"  {d.strftime('%Y-%m-%d')}")
    except Exception as e:
        print("Date alignment check failed:", e)

print("\n--- 3. Testing 400 Bad Request on Insufficient History / Invalid Ticker ---")
# Hit local server endpoint directly or test local client
import requests
import json

url = "http://127.0.0.1:5000/api/ensemble_forecast"
payload = {
    "ticker": "INVALID_TICKER_XYZ",
    "horizon": 10
}
try:
    print("Hitting local server with invalid ticker:", payload["ticker"])
    response = requests.post(url, json=payload, timeout=20)
    print("Response Status Code:", response.status_code)
    print("Response JSON:")
    print(json.dumps(response.json(), indent=2))
except Exception as e:
    print("API Query failed (is the Flask server running?):", e)
