import os
import sys
# Insert project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

sys.stdout.reconfigure(encoding='utf-8')

from app import app, kronos_predict, prophet_predict, arima_predict, ensemble_blend

TEST_TICKERS = ['RELIANCE.NS', 'HDFCBANK.NS', 'INFY.NS']

with app.app_context():
    for ticker in TEST_TICKERS:
        print(f'\n=== {ticker} ===')
        try:
            print("  Running Kronos Predict...")
            k = kronos_predict(ticker, horizon=10)
            print(f'  Kronos   : {[round(x,1) for x in k]}')
            
            print("  Running Prophet Predict...")
            p = prophet_predict(ticker, horizon=10)
            print(f'  Prophet  : {[round(x,1) for x in p]}')
            
            print("  Running ARIMA Predict...")
            a = arima_predict(ticker, horizon=10)
            print(f'  ARIMA    : {[round(x,1) for x in a]}')
            
            print("  Running Ensemble Blend...")
            blend = ensemble_blend(k, p, a)
            print(f'  Ensemble : {[round(x,1) for x in blend["ensemble_path"]]}')
            print(f'  Divergence: {blend["divergence_score"]} | Conviction: {blend["conviction"]}')
        except Exception as e:
            print(f'  ERROR: {e}')
