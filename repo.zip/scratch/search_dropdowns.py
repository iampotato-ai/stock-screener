with open("static/js/app.js", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "btn-ims" in line or "ims-dropdown" in line or "btn-swing" in line or "swing-dropdown" in line:
        print(f"{i+1}: {line.strip()}")
