import requests, time, sys

BASE = "http://127.0.0.1:5000"

# Wait for server
for i in range(15):
    try:
        r = requests.get(f"{BASE}/api/nse-holidays", timeout=3)
        if r.status_code == 200:
            print("Server ready")
            break
    except Exception:
        print(f"Waiting for server... ({i+1})")
        time.sleep(2)
else:
    print("Server not ready, aborting")
    sys.exit(1)

print("\n=== Testing CGPOWER Ensemble Forecast ===")
r = requests.post(
    f"{BASE}/api/ensemble_forecast",
    json={"ticker": "CGPOWER", "horizon": 10, "use_dynamic_weights": True},
    timeout=60
)
print(f"HTTP Status: {r.status_code}")
if r.status_code == 200:
    d = r.json()
    conviction   = d.get("conviction", "MISSING")
    divergence   = d.get("divergence_score", "MISSING")
    weights      = d.get("weights", {})
    matrix       = d.get("agreement_matrix", {})
    ensemble_path = d.get("ensemble_path", [])
    model_paths  = d.get("model_paths", {})
    cached       = d.get("cached", False)
    print(f"Cached:      {cached}")
    print(f"Conviction:  {conviction}")
    print(f"Divergence:  {divergence}")
    print(f"Weights:     {weights}")
    print(f"Matrix keys: {list(matrix.keys())}")
    print(f"Ensemble path length: {len(ensemble_path)}, first 3: {ensemble_path[:3]}")
    for m, p in model_paths.items():
        status = f"OK ({len(p)} pts)" if p else "MISSING/EMPTY"
        print(f"  model_paths[{m}]: {status}")
    if conviction and conviction != "MISSING" and len(ensemble_path) > 0:
        print("\nASSERTIONS PASSED - all fields present")
    else:
        print("\nASSERTIONS FAILED - missing conviction or ensemble_path")
else:
    print("Error response:")
    print(r.text[:1000])
