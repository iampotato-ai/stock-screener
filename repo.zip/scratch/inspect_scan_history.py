import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

print("Schema of scan_history:")
c.execute("PRAGMA table_info(scan_history)")
print(c.fetchall())

print("\nSchema of scan_price_log:")
c.execute("PRAGMA table_info(scan_price_log)")
print(c.fetchall())

print("\nDistinct dates in scan_history:")
c.execute("SELECT DISTINCT date FROM scan_history ORDER BY date DESC")
print(c.fetchall())

print("\nDistinct dates in scan_price_log:")
c.execute("SELECT DISTINCT date FROM scan_price_log ORDER BY date DESC")
print(c.fetchall())

conn.close()
