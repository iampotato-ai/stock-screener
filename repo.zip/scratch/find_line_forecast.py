with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if '@app.route(\'/api/kronos-forecast\'' in line or '@app.route("/api/kronos-forecast"' in line:
        print(f"Line {idx+1}: {line.strip()}")
        break
