with open(r'c:\Users\91996\Documents\My Projects\stock-screener\static\js\app.js', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'Model did not run or threw an error' in line:
        print(f"Line {idx+1}: {line.strip()}")
        for j in range(idx-10, idx+20):
            print(f"{j+1}: {lines[j].rstrip()}")
        break
