import yfinance as yf
import pandas as pd
import datetime

def parse_yfinance_fundamentals(symbol):
    try:
        # Try NSE first, fall back to BSE ticker format
        ticker = yf.Ticker(f"{symbol}.NS")
        df = ticker.quarterly_income_stmt
        if df is None or df.empty:
            ticker = yf.Ticker(f"{symbol}.BO")
            df = ticker.quarterly_income_stmt
            if df is None or df.empty:
                return []
                
        parsed_quarters = []
        # Columns in quarterly_income_stmt are Timestamp objects (representing quarter end dates)
        for col in df.columns:
            if not isinstance(col, (pd.Timestamp, datetime.datetime)):
                continue
                
            date_key = col.strftime("%Y-%m-%d")
            
            # Form quarter name e.g., 'Dec 2024'
            month_names = {
                1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
                7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec"
            }
            q_name = month_names.get(col.month, "Q")
            quarter_label = f"{q_name} {col.year}"
            
            # Extract row values
            # Total Revenue or Operating Revenue
            revenue_val = None
            for idx in ["Total Revenue", "Operating Revenue"]:
                if idx in df.index:
                    val = df.loc[idx, col]
                    if pd.notna(val) and val != 0:
                        revenue_val = round(float(val) / 10000000.0, 2) # Rs to Crores
                        break
            
            # Net Income or Net Income Common Stockholders
            net_profit_val = None
            for idx in ["Net Income", "Net Income Common Stockholders", "Net Income Including Noncontrolling Interests"]:
                if idx in df.index:
                    val = df.loc[idx, col]
                    if pd.notna(val):
                        net_profit_val = round(float(val) / 10000000.0, 2) # Rs to Crores
                        break
                        
            # Basic EPS or Diluted EPS
            eps_val = None
            for idx in ["Basic EPS", "Diluted EPS"]:
                if idx in df.index:
                    val = df.loc[idx, col]
                    if pd.notna(val):
                        eps_val = round(float(val), 2)
                        break
                        
            parsed_quarters.append({
                "quarter": quarter_label,
                "date_key": date_key,
                "result_date": date_key, # Use end date as proxy
                "revenue": revenue_val,
                "net_profit": net_profit_val,
                "eps": eps_val
            })
            
        # Sort chronologically
        parsed_quarters.sort(key=lambda x: x["date_key"])
        return parsed_quarters
    except Exception as e:
        print(f"Error parsing yfinance data for {symbol}: {e}")
        return []

# Test with CAPILLARY
res = parse_yfinance_fundamentals("CAPILLARY")
print("Parsed CAPILLARY from yfinance:")
for q in res:
    print(q)
