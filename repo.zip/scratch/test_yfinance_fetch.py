import yfinance as yf

symbol = "CAPILLARY.NS"
ticker = yf.Ticker(symbol)

# Try fetching financials with different methods to get more history
try:
    print("Income statement shape:", ticker.quarterly_income_stmt.shape)
    print("Columns:", list(ticker.quarterly_income_stmt.columns))
except Exception as e:
    print("Error:", e)

try:
    # yfinance sometimes supports fetching historical financials through fetchers or other attributes
    print("\nKeys in ticker.info:")
    info = ticker.info
    print("Price to sales:", info.get("priceToSalesTrailing12Months"))
    print("Enterprise value:", info.get("enterpriseValue"))
except Exception as e:
    print("Error:", e)

# Let's see if we can get financials for another symbol like RELIANCE.NS
ticker_rel = yf.Ticker("RELIANCE.NS")
print("\nRELIANCE quarterly income stmt shape:", ticker_rel.quarterly_income_stmt.shape)
print("RELIANCE Columns:", list(ticker_rel.quarterly_income_stmt.columns))
