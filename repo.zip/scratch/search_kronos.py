import os
import sys

# Set standard output encoding to utf-8
sys.stdout.reconfigure(encoding='utf-8')

files_to_search = [
    "app.py",
    "templates/index.html",
    "static/css/style.css",
    "static/js/app.js"
]

base_dir = r"c:\Users\91996\Documents\My Projects\stock-screener"

for filename in files_to_search:
    filepath = os.path.join(base_dir, filename)
    if not os.path.exists(filepath):
        print(f"Skipping {filename}: not found")
        continue
    print(f"\n=== Searching in {filename} ===")
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    for idx, line in enumerate(lines, 1):
        if "kronos" in line.lower():
            print(f"Line {idx}: {line.strip()}")
