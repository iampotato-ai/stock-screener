import urllib.request
import json
import time

def run_post_request(url):
    print(f"Triggering POST request to: {url}")
    req = urllib.request.Request(url, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=40) as response:
            data = json.loads(response.read().decode('utf-8'))
            print("Response:", data)
            return data
    except Exception as e:
        print("Error:", e)
        return None

def run_get_request(url):
    print(f"Triggering GET request to: {url}")
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            data = json.loads(response.read().decode('utf-8'))
            return data
    except Exception as e:
        print("Error:", e)
        return None

def test_rrg_timeline():
    # 1. Test backfill
    backfill_url = "http://127.0.0.1:5000/api/rrg/backfill"
    res = run_post_request(backfill_url)
    if not res or not res.get("success"):
        print("Backfill failed, aborting further checks.")
        return

    # Wait a moment
    time.sleep(1)

    # 2. Test get history
    history_url = "http://127.0.0.1:5000/api/rrg/history?weeks=12"
    history_data = run_get_request(history_url)
    if history_data:
        print("\nGet RRG History check:")
        print(f"  Weeks requested: {history_data.get('weeks')}")
        frames = history_data.get('frames', [])
        print(f"  Frames returned: {len(frames)}")
        if frames:
            print("  First frame week:", frames[0].get("week"))
            print("  First frame sectors count:", len(frames[0].get("sectors", [])))
            print("  Last frame week:", frames[-1].get("week"))
            print("  Last frame sectors count:", len(frames[-1].get("sectors", [])))
            
            # Print sample sector details from the last frame
            if frames[-1].get("sectors"):
                sample = frames[-1]["sectors"][0]
                print(f"  Sample Sector: {sample.get('sector')} | jdk_rs: {sample.get('jdk_rs')} | momentum: {sample.get('jdk_rs_momentum')} | quadrant: {sample.get('quadrant')}")
    else:
        print("Failed to get RRG history.")

    # 3. Test manual snapshot
    snap_url = "http://127.0.0.1:5000/api/rrg/snapshot"
    run_post_request(snap_url)

if __name__ == "__main__":
    test_rrg_timeline()
