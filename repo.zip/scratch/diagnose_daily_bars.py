import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

# Get distinct dates in scan_history
c.execute("SELECT DISTINCT date FROM scan_history ORDER BY date DESC LIMIT 20")
dates = c.fetchall()
print("Latest 20 dates in scan_history:")
for d in dates:
    # Get count of stocks for this date
    c.execute("SELECT COUNT(*) FROM scan_history WHERE date = ?", (d[0],))
    cnt = c.fetchone()[0]
    print(f"  {d[0]}: {cnt} stocks")

# Get total distinct dates in scan_history
c.execute("SELECT COUNT(DISTINCT date) FROM scan_history")
total_dates = c.fetchone()[0]
print(f"\nTotal distinct dates in scan_history: {total_dates}")

conn.close()
