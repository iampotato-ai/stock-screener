import sqlite3

conn = sqlite3.connect(r'c:\Users\91996\Documents\My Projects\stock-screener\scan_history.db')
cursor = conn.cursor()

print("=== Stored Database Cache Values ===")
cursor.execute('SELECT * FROM ipo_metrics_cache WHERE ticker LIKE ? OR ticker LIKE ?', ('%SEDEMAC%', '%SHADOWFAX%'))
cols = [d[0] for d in cursor.description]
for r in cursor.fetchall():
    d = dict(zip(cols, r))
    print(f"\nTicker: {d['ticker']}")
    print(f"  Current Price: {d.get('current_price')}")
    print(f"  Day's Low: {d.get('day_low')}")
    print(f"  Day's High: {d.get('day_high')}")
    print(f"  Day's Change %: {d.get('change_pct')}%")
    print(f"  Volume: {d.get('volume')}")
    print(f"  Swing Score: {d.get('swing_score')}/10")
    print(f"  Phase: {d.get('momentum_phase')}")

conn.close()
