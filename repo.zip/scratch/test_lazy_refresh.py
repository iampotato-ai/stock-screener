import sqlite3
from app import create_app
from app.api.v1.legacy_routes import get_ep_detail

def main():
    conn = sqlite3.connect('scan_history.db')
    c = conn.cursor()
    c.execute("SELECT quarter, result_date FROM fundamentals WHERE symbol = 'TARIL' ORDER BY result_date DESC LIMIT 3")
    print("Before detail call:", c.fetchall())
    conn.close()
    
    app = create_app()
    with app.app_context():
        # Get EP detail response (Flask Response object)
        response = get_ep_detail('TARIL')
        data = response.get_json()
        
        print("\nRefreshed fundamentals from endpoint:")
        for f in data.get('fundamentals', [])[:5]:
            print(f"  {f['quarter']}: {f['result_date']}")

if __name__ == '__main__':
    main()
