with open('scan_history.db', 'rb') as f:
    f.seek(108000)
    data = f.read(8000)

# Let's find any text matches
# We can search for any ASCII strings
import string
printable_chars = set(string.printable.encode('ascii'))

current_str = bytearray()
strings = []
for idx, b in enumerate(data):
    if b in printable_chars and b not in [10, 13]: # ignore newlines
        current_str.append(b)
    else:
        if len(current_str) >= 4:
            strings.append((idx - len(current_str) + 108000, current_str.decode('ascii', errors='ignore')))
        current_str = bytearray()

print("Strings found in the range 108000 to 116000:")
for pos, s in strings:
    # Filter out long sequences of dots or spaces
    if not s.strip('.'):
        continue
    print(f"  Pos {pos:6d}: {s}")
