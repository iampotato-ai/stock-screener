import urllib.request
import zipfile
import io
import os

def download_and_extract():
    urls = [
        "https://github.com/shiyu-coder/Kronos/archive/refs/heads/main.zip",
        "https://github.com/shiyu-coder/Kronos/archive/refs/heads/master.zip"
    ]
    
    os.makedirs("scratch", exist_ok=True)
    
    success = False
    for url in urls:
        print(f"Trying to download {url}...")
        try:
            req = urllib.request.Request(
                url, 
                headers={'User-Agent': 'Mozilla/5.0'}
            )
            with urllib.request.urlopen(req) as response:
                zip_data = response.read()
                print("Download complete. Extracting...")
                with zipfile.ZipFile(io.BytesIO(zip_data)) as zip_ref:
                    zip_ref.extractall("scratch")
                print("Extraction complete.")
                success = True
                break
        except Exception as e:
            print(f"Failed to download from {url}: {e}")
            
    if success:
        # Locate the extracted directory and rename/move its contents
        extracted_dirs = [d for d in os.listdir("scratch") if d.startswith("Kronos-")]
        if extracted_dirs:
            src = os.path.join("scratch", extracted_dirs[0])
            dest = os.path.join("scratch", "Kronos")
            if os.path.exists(dest):
                import shutil
                shutil.rmtree(dest)
            os.rename(src, dest)
            print(f"Renamed {src} to {dest}")
        else:
            print("Warning: Could not find extracted Kronos directory starting with Kronos-")

if __name__ == "__main__":
    download_and_extract()
