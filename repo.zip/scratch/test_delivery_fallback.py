import sys
import os
sys.path.insert(0, os.path.abspath('.'))

import app

# 2026-06-12 is today and doesn't have delivery data yet (or might fail with 404).
# We want to verify that calling fetch_nse_delivery_data('2026-06-12') walks backward
# and successfully loads data from n-1 (e.g. 2026-06-11 or prior).
result = app.fetch_nse_delivery_data('2026-06-12')
if result:
    print(f"Success! Loaded {len(result)} symbols.")
else:
    print("Failed to load delivery data.")
