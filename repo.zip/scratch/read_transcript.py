import os
import json
import sys
sys.stdout.reconfigure(encoding='utf-8')

log_file = r"C:\Users\91996\.gemini\antigravity\brain\edf246d5-649b-41e1-b712-ccc288cf2203\.system_generated\logs\transcript.jsonl"
if os.path.exists(log_file):
    print("Found transcript.jsonl, scanning...")
    with open(log_file, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                step = json.loads(line)
                if step.get('type') == 'USER_INPUT':
                    print(f"\n--- USER INPUT (Step {step.get('step_index')}) ---")
                    print(step.get('content'))
                elif step.get('type') == 'PLANNER_RESPONSE':
                    content = step.get('content') or ""
                    if 'pr #' in content.lower() or 'findings' in content.lower() or 'code review' in content.lower():
                        print(f"\n--- PLANNER RESPONSE (Step {step.get('step_index')}) ---")
                        # print first 300 chars of matching planner response
                        print(content[:300] + "...")
            except Exception as e:
                pass
else:
    print("transcript.jsonl not found.")
