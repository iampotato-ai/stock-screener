import sqlite3

def check_db(filename):
    print(f"\n--- Database: {filename} ---")
    try:
        conn = sqlite3.connect(filename)
        c = conn.cursor()
        c.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = c.fetchall()
        print("Tables:")
        for t in tables:
            tname = t[0]
            c.execute(f"PRAGMA table_info({tname})")
            cols = [col[1] for col in c.fetchall()]
            c.execute(f"SELECT COUNT(*) FROM {tname}")
            cnt = c.fetchone()[0]
            print(f"  {tname} ({cnt} rows): {cols}")
        conn.close()
    except Exception as e:
        print(f"Error: {e}")

check_db('stocks.db')
check_db('scan_history.db')
