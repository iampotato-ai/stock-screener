import sys
sys.stdout.reconfigure(encoding='utf-8')

with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'sqlite3.connect' in line:
        print(f"Line {idx+1}: {line.strip()}")
    if 'get_db_connection' in line:
        print(f"Line {idx+1}: {line.strip()}")
