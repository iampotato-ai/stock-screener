import sys
sys.stdout.reconfigure(encoding='utf-8')

log_uri = r"C:\Users\91996\.gemini\antigravity\brain\edf246d5-649b-41e1-b712-ccc288cf2203\.system_generated\tasks\task-11626.log"
with open(log_uri, 'r', encoding='utf-8') as f:
    print(f.read())
