import requests
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

url = "http://127.0.0.1:5000/api/ensemble_forecast"
payload = {
    "ticker": "RELIANCE.NS",
    "horizon": 10,
    "use_dynamic_weights": False
}

print("Sending POST request to:", url)
print("Payload:", json.dumps(payload))

try:
    response = requests.post(url, json=payload, timeout=20)
    print("\nStatus Code:", response.status_code)
    print("Response JSON:")
    print(json.dumps(response.json(), indent=2))
except Exception as e:
    print("ERROR:", e)
