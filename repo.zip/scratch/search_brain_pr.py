import os
import sys
sys.stdout.reconfigure(encoding='utf-8')

brain_dir = r'C:\Users\91996\.gemini\antigravity\brain\edf246d5-649b-41e1-b712-ccc288cf2203'
for root, dirs, files in os.walk(brain_dir):
    for f in files:
        path = os.path.join(root, f)
        f_lower = f.lower()
        if 'review' in f_lower or 'pr' in f_lower or 'finding' in f_lower or 'ensemble' in f_lower:
            print(f"Found file by name: {path}")
        if f.endswith('.md') or f.endswith('.txt') or f.endswith('.json'):
            try:
                with open(path, 'r', encoding='utf-8') as file:
                    content = file.read()
                if 'ensemble' in content.lower() and ('review' in content.lower() or 'finding' in content.lower() or 'pr' in content.lower()):
                    # Print first 200 chars or context
                    print(f"Found keyword in contents of: {path}")
            except Exception as e:
                pass
print("Search complete.")
