with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'get_setup_analysis' in line:
        print(f"Line {idx+1}: {line.strip()}")
        # print next 25 lines
        for j in range(idx, idx+25):
            print(f"{j+1}: {lines[j].rstrip()}")
        break
