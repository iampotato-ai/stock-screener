import unittest
import json
import sqlite3
from app import app

class TestWatchlistSQLiteReorder(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        
        # Ensure clean state for our test sections
        conn = sqlite3.connect('scan_history.db')
        c = conn.cursor()
        c.execute("DELETE FROM watchlist_items WHERE section_id = 'test-reorder-sec'")
        c.execute("DELETE FROM watchlist_sections WHERE id = 'test-reorder-sec'")
        c.execute("DELETE FROM watchlist_items WHERE section_id = 'sec-test-migrated'")
        c.execute("DELETE FROM watchlist_sections WHERE id = 'sec-test-migrated'")
        c.execute("INSERT OR REPLACE INTO watchlist_sections (id, name) VALUES ('test-reorder-sec', 'Test Reorder Section')")
        conn.commit()
        conn.close()

    def tearDown(self):
        conn = sqlite3.connect('scan_history.db')
        c = conn.cursor()
        c.execute("DELETE FROM watchlist_items WHERE section_id = 'test-reorder-sec'")
        c.execute("DELETE FROM watchlist_sections WHERE id = 'test-reorder-sec'")
        c.execute("DELETE FROM watchlist_items WHERE section_id = 'sec-test-migrated'")
        c.execute("DELETE FROM watchlist_sections WHERE id = 'sec-test-migrated'")
        conn.commit()
        conn.close()

    def test_add_items_with_positions(self):
        # 1. Add item 1
        resp = self.app.post('/api/watchlist/items', json={
            'section_id': 'test-reorder-sec',
            'ticker': 'AAPL'
        })
        self.assertEqual(resp.status_code, 200)
        
        # 2. Add item 2
        resp = self.app.post('/api/watchlist/items', json={
            'section_id': 'test-reorder-sec',
            'ticker': 'GOOG'
        })
        self.assertEqual(resp.status_code, 200)

        # Verify initial positions in DB
        conn = sqlite3.connect('scan_history.db')
        c = conn.cursor()
        c.execute("SELECT ticker, position FROM watchlist_items WHERE section_id = 'test-reorder-sec' ORDER BY position")
        rows = c.fetchall()
        conn.close()
        
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0][0], 'AAPL')
        self.assertEqual(rows[0][1], 1)
        self.assertEqual(rows[1][0], 'GOOG')
        self.assertEqual(rows[1][1], 2)

    def test_reorder_endpoint(self):
        # Add a couple of items
        self.app.post('/api/watchlist/items', json={'section_id': 'test-reorder-sec', 'ticker': 'AAPL'})
        self.app.post('/api/watchlist/items', json={'section_id': 'test-reorder-sec', 'ticker': 'GOOG'})
        self.app.post('/api/watchlist/items', json={'section_id': 'test-reorder-sec', 'ticker': 'MSFT'})

        # Reorder them
        resp = self.app.put('/api/watchlist/sections/test-reorder-sec/reorder', json={
            'stocks': ['MSFT', 'GOOG', 'AAPL']
        })
        self.assertEqual(resp.status_code, 200)

        # Check DB positions
        conn = sqlite3.connect('scan_history.db')
        c = conn.cursor()
        c.execute("SELECT ticker, position FROM watchlist_items WHERE section_id = 'test-reorder-sec' ORDER BY position")
        rows = c.fetchall()
        conn.close()

        self.assertEqual(rows[0][0], 'MSFT')
        self.assertEqual(rows[0][1], 0)
        self.assertEqual(rows[1][0], 'GOOG')
        self.assertEqual(rows[1][1], 1)
        self.assertEqual(rows[2][0], 'AAPL')
        self.assertEqual(rows[2][1], 2)

    def test_local_data_migration_position(self):
        migration_payload = {
            "watchlist_sections": [
                {
                    "id": "sec-test-migrated",
                    "name": "Migrated Watchlist",
                    "stocks": ["RELIANCE", "TCS", "INFY"]
                }
            ],
            "journal": []
        }
        resp = self.app.post('/api/migrate-local-data', json=migration_payload)
        self.assertEqual(resp.status_code, 200)

        # Check DB positions for migrated items
        conn = sqlite3.connect('scan_history.db')
        c = conn.cursor()
        c.execute("SELECT ticker, position FROM watchlist_items WHERE section_id = 'sec-test-migrated' ORDER BY position")
        rows = c.fetchall()
        conn.close()

        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[0][0], 'RELIANCE')
        self.assertEqual(rows[0][1], 0)
        self.assertEqual(rows[1][0], 'TCS')
        self.assertEqual(rows[1][1], 1)
        self.assertEqual(rows[2][0], 'INFY')
        self.assertEqual(rows[2][1], 2)

if __name__ == '__main__':
    unittest.main()
