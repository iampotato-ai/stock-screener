import sqlite3

conn = sqlite3.connect('scan_history.db')
c = conn.cursor()

tables = ["daily_bars", "fundamentals", "corporate_events", "ep_features", "ep_watchlist", "sugar_babies"]
print("Row counts in scan_history.db:")
for t in tables:
    try:
        c.execute(f"SELECT COUNT(*) FROM {t}")
        print(f"  {t}: {c.fetchone()[0]}")
    except sqlite3.OperationalError as e:
        print(f"  {t}: Error: {e}")

conn.close()
