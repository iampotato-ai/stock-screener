import re

def scan_db():
    with open('scan_history.db', 'rb') as f:
        data = f.read()
    
    # Search for date strings like 2026-06-18 or 2026-06-19 etc.
    # We want to find matches of YYYY-MM-DD in ASCII/UTF-8
    matches = re.findall(rb'\b(202\d-\d{2}-\d{2})\b', data)
    
    # Unique dates found
    dates = sorted(list(set(matches)))
    print(f"Total date matches: {len(matches)}")
    print(f"Unique dates: {[d.decode('ascii') for d in dates]}")

if __name__ == '__main__':
    scan_db()
