import os
import shutil

def copy_model():
    os.makedirs("model", exist_ok=True)
    src_dir = os.path.join("scratch", "Kronos", "model")
    dest_dir = "model"
    
    files = ["__init__.py", "kronos.py", "module.py"]
    for file in files:
        src_path = os.path.join(src_dir, file)
        dest_path = os.path.join(dest_dir, file)
        shutil.copy2(src_path, dest_path)
        print(f"Copied {src_path} to {dest_path}")

if __name__ == "__main__":
    copy_model()
