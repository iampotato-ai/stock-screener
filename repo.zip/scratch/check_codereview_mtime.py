import os
import time
import sys
sys.stdout.reconfigure(encoding='utf-8')

path = r"c:\Users\91996\Documents\My Projects\stock-screener\codereview.md"
if os.path.exists(path):
    print("MTime:", time.ctime(os.path.getmtime(path)))
    print("Size:", os.path.getsize(path))
    with open(path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    print("Total lines:", len(lines))
    print("Last 20 lines:")
    for l in lines[-20:]:
        print(l.rstrip())
else:
    print("File not found.")
