with open(r'c:\Users\91996\Documents\My Projects\stock-screener\app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx in range(1720, 1742):
    if idx < len(lines):
        print(f"{idx+1}: {lines[idx].rstrip()}")
