import datetime
import requests
import json
import sys

def fetch_nse_fundamentals(symbol):
    session = requests.Session()
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "Referer": "https://www.nseindia.com/companies-listing/corporate-filings-announcements",
    }
    
    try:
        # Step 1: visit referer
        session.get("https://www.nseindia.com/companies-listing/corporate-filings-announcements", headers=headers, timeout=10)
        
        # Step 2: request API
        url = f"https://www.nseindia.com/api/results-comparision?symbol={symbol}"
        res = session.get(url, headers=headers, timeout=10)
        if res.status_code != 200:
            return None
            
        data = res.json()
        cmp_data = data.get("resCmpData", [])
        if not cmp_data:
            return []
            
        months_map = {
            "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
            "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12
        }
        
        parsed_quarters = []
        for row in cmp_data:
            # Parse 're_to_dt' (e.g., '31-DEC-2024')
            to_dt_str = row.get("re_to_dt")
            if not to_dt_str:
                continue
            
            parts = to_dt_str.split('-')
            if len(parts) != 3:
                continue
                
            day = int(parts[0])
            month_str = parts[1].upper()
            year = int(parts[2])
            month = months_map.get(month_str)
            if not month:
                continue
                
            date_key = f"{year:04d}-{month:02d}-{day:02d}"
            
            # Form quarter name e.g., 'Dec 2024'
            month_names = {
                3: "Mar", 6: "Jun", 9: "Sep", 12: "Dec"
            }
            q_name = month_names.get(month, month_str)
            quarter_label = f"{q_name} {year}"
            
            # Parse 're_create_dt' for result date (e.g., '16-JAN-2025')
            result_date = None
            create_dt_str = row.get("re_create_dt")
            if create_dt_str:
                c_parts = create_dt_str.split('-')
                if len(c_parts) == 3:
                    c_day = int(c_parts[0])
                    c_month = months_map.get(c_parts[1].upper(), 1)
                    c_year = int(c_parts[2])
                    result_date = f"{c_year:04d}-{c_month:02d}-{c_day:02d}"
            
            # Sales / Revenue: 're_net_sale' in Lakhs
            rev_lakhs = row.get("re_net_sale")
            revenue = None
            if rev_lakhs is not None:
                revenue = round(float(str(rev_lakhs).replace(',', '')) / 100.0, 2) # Lakhs to Crores
                
            # Net Profit: 're_net_profit' in Lakhs
            profit_lakhs = row.get("re_net_profit") or row.get("re_con_pro_loss")
            net_profit = None
            if profit_lakhs is not None:
                net_profit = round(float(str(profit_lakhs).replace(',', '')) / 100.0, 2) # Lakhs to Crores
                
            # EPS: 're_basic_eps_for_cont_dic_opr'
            eps_val = row.get("re_basic_eps_for_cont_dic_opr") or row.get("re_dilut_eps_for_cont_dic_opr") or row.get("re_basic_eps")
            eps = None
            if eps_val is not None:
                eps = round(float(str(eps_val).replace(',', '')), 2)
                
            parsed_quarters.append({
                "quarter": quarter_label,
                "date_key": date_key,
                "result_date": result_date,
                "revenue": revenue,
                "net_profit": net_profit,
                "eps": eps
            })
            
        # Sort by date_key ascending so they match chronological order of fundamentals_list
        parsed_quarters.sort(key=lambda x: x["date_key"])
        return parsed_quarters
        
    except Exception as e:
        print("Parsing exception:", e)
        return None

symbol = "TCS" if len(sys.argv) < 2 else sys.argv[1]
res = fetch_nse_fundamentals(symbol)
if res:
    print(f"Successfully parsed {len(res)} quarters for {symbol}:")
    for q in res:
        print(f"  {q['quarter']} ({q['date_key']}) - result_date: {q['result_date']}: revenue={q['revenue']} Cr, net_profit={q['net_profit']} Cr, eps=Rs {q['eps']}")
else:
    print("Failed to fetch/parse.")
