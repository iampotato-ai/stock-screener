import os
import json
import sys
sys.stdout.reconfigure(encoding='utf-8')

log_file = r"C:\Users\91996\.gemini\antigravity\brain\edf246d5-649b-41e1-b712-ccc288cf2203\.system_generated\logs\transcript.jsonl"
if os.path.exists(log_file):
    print("Scanning transcript.jsonl for all findings and reviews...")
    with open(log_file, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                step = json.loads(line)
                content = step.get('content') or ""
                # search for target keywords
                lower_content = content.lower()
                if 'finding' in lower_content or 'review' in lower_content or 'pr #1' in lower_content or 'pull request #1' in lower_content:
                    # check if it contains ensemble or kronos
                    if 'ensemble' in lower_content or 'kronos' in lower_content:
                        print(f"\nStep {step.get('step_index')} ({step.get('type')}):")
                        # print first 500 chars
                        print(content[:500] + ("..." if len(content) > 500 else ""))
            except Exception:
                pass
print("Scan complete.")
