import sqlite3

def count_rows():
    conn = sqlite3.connect('C:/Users/91996/scan_history.db')
    c = conn.cursor()
    c.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [t[0] for t in c.fetchall()]
    print("Row counts in tables:")
    for t in tables:
        c.execute(f"SELECT COUNT(*) FROM {t}")
        count = c.fetchone()[0]
        print(f"  {t}: {count}")
    conn.close()

if __name__ == '__main__':
    count_rows()
